# AROSTER CAMM — status 0.8.0

| الميزة | الحالة في المصدر |
|---|---|
| CameraX still capture بأولوية الجودة وJPEG 98 | موجود |
| تعريض متكيف + ضغط الإضاءات + تدرج سينمائي وحماية البشرة | موجود |
| Portrait blur عبر ML Kit | موجود، يعتمد على الجهاز |
| AI Smart Shot | موجود |
| Motion Capture صورة + مقطع مرافق | موجود، ليس Apple Live Photo |
| FHD video مع fallback | موجود حسب دعم الجهاز |
| EIS وقت التسجيل | عند إعلان دعم الكاميرا |
| VIDEO LAB | تلوين/قص وتصحيح roll محدود، ليس Optical Flow AI |
| بانوراما أفقية | موجودة، 12 إطارًا |
| Night Sight stack | موجود مبدئيًا: 4 إطارات + تعريض موجب + محاذاة انتقالية + دمج مقاوم للحركة |
| Photo Sphere 360 | موجود مبدئيًا: 48 اتجاهًا + إسقاط Equirectangular + GPano XMP |
| AI Super Resolution | لا يوجد نموذج متوافق مرفق |
| Neural video stabilization / AI video denoise | غير منفّذ |

## ملاحظات الجودة
Night Stack يقلل الضوضاء في المشاهد الثابتة، لكن الحركة داخل المشهد أو تحريك الهاتف بشدة قد ينتج عنه شبح/طمس. Photo Sphere يعتمد على مجال رؤية تقريبي 66°، ومستشعر اتجاه الهاتف، و48 لقطة موزعة على 360° والارتفاعات والقطبين. يلزم اختبار محاذاة الاتجاهات ومجال الرؤية على الجهاز المستهدف قبل وصف النتيجة بأنها مطابقة لجوجل كاميرا.

## التحقق والبناء
تم التحقق من ملفات XML وفحص ربط عناصر الواجهة ووجود ملفات المصدر. لا يتوفر Android SDK أو Gradle في بيئة الإنشاء، لذلك لم يتم تنفيذ Gradle build أو تشغيل على هاتف فعلي. لم يتم إصدار APK.

## v0.9.0 Live Photo implementation
Implemented a single-file Google Camera-style Motion Photo: capture a still at recording start, record a 3-second MP4, then append the MP4 to the processed JPEG and insert XMP APP1 metadata with `GCamera:MicroVideoOffset`. Saved under `Pictures/AROSTER CAMM/Live Photos`.

Known limitation: CameraX Recorder does not provide pre-shutter circular buffering. The 3-second motion segment begins at the shutter event, rather than containing 1.5 seconds before and 1.5 seconds after like Apple's Live Photos. Playback requires a Motion Photo-aware gallery/viewer. Full Gradle build and device validation remain pending because Gradle/Android SDK are not installed in this environment.


## Live Photo Pre/Post Roll (v1.0.0)
تم تعديل Live Photo لتستخدم مخزن إطارات دائريًا من ImageAnalysis: 1.5 ثانية قبل ضغط زر التصوير، ثم التقاط الصورة الثابتة، ثم انتظار 1.5 ثانية بعد الضغط. تُجمع الإطارات وتُشفّر إلى MP4 H.264 ثم تُضمّن داخل JPEG ببيانات Google Motion Photo XMP، مع ضبط Presentation Timestamp عند 1.5 ثانية. يتطلب ذلك استمرار ImageAnalysis؛ إذا لم يدعم الجهاز ربط التحليل مع الكاميرا والفيديو معًا فلن يتوفر التسجيل المسبق. جودة مقطع الحركة أقل من الصورة الثابتة ويعتمد معدل الإطارات على أداء الجهاز. لم يتم تنفيذ Android Build أو اختبار فعلي على جهاز في بيئة الإنشاء.
