# AROSTER CAMM v0.8.0

تطبيق كاميرا Android تجريبي باستخدام Kotlin وCameraX، بواجهة داكنة مستوحاة من Liquid Glass.

## الميزات الجديدة في 0.8.0
- وضع NIGHT SIGHT: يلتقط أربع إطارات مع تعويض تعريض موجب عندما تسمح الكاميرا، ثم يحاذيها بإزاحة عامة ويدمجها لتقليل الضوضاء. هذه معالجة متعددة الإطارات وليست نموذجًا عصبيًا أو بديلًا كاملًا لوضع Night Sight في هواتف Pixel.
- وضع PHOTO SPHERE 360°: التقاط تلقائي موجّه عبر مستشعر الاتجاه في شبكة من 48 اتجاهًا (ثلاث حلقات أفقية/رأسية مع لقطات للقطبين)، ثم إسقاط اللقطات على صورة Equirectangular بنسبة 2:1.
- إضافة بيانات GPano XMP إلى صورة Photo Sphere حتى تتعرف عليها تطبيقات عرض الصور المتوافقة مع بيانات Google Panorama.
- إبقاء لقطات Photo Sphere مؤقتة داخل ذاكرة التطبيق وعدم وضع 48 صورة وسيطة في معرض الهاتف.

## وظائف سابقة
- تصوير CameraX بأولوية الجودة مع الفلاش والكاميرا الأمامية والخلفية.
- Portrait بعزل الخلفية باستخدام ML Kit Selfie Segmentation.
- AI Smart Shot لاكتشاف الوجه والابتسامة وفتح العينين.
- Motion Capture بصورة ومقطع قصير مرافق (ليس صيغة Live Photo أصلية).
- تصوير فيديو FHD مع اختيار جودة بديلة وفق دعم الجهاز، وتثبيت إلكتروني عند توفره.
- VIDEO LAB لتدرج الفيديو وتصحيح دوران محدود باستخدام سجل الجيروسكوب.
- بانوراما أفقية من لقطات متداخلة، بجانب وضع Photo Sphere الكروي الجديد.
- تقريب، تعويض تعريض، Tap-to-Focus، مؤقت، وخطوط تكوين.

## حدود مهمة
وضع Night يعتمد على تعويض التعريض المدعوم من CameraX ومحاذاة انتقالية عامة ودمج الإطارات؛ لا يحتوي على محاذاة محلية متقدمة أو معالجة RAW أو نموذج AI مخصص. وضع Photo Sphere يعتمد حاليًا على مجال رؤية تقريبي 66° ومصفوفات اتجاه الهاتف، لذلك قد تظهر فواصل أو مناطق غير مثالية بحسب العدسة ومعايرة المستشعر وسرعة الحركة. هذا مسار Photo Sphere كروي حقيقي بالإسقاط وبيانات GPano، لكنه ليس خوارزمية Google Camera الأصلية.

التدرج اللوني ومعالجة الإضاءة تحسينات حسابية محلية وليست إضاءة توليدية. لا توجد حاليًا نماذج موثقة ومرفقة لـ AI Super Resolution أو تثبيت Optical Flow أو إزالة ضوضاء الفيديو. جودة النتيجة تتأثر بحساس الهاتف والعدسة والإضاءة ودعم Camera HAL.

## البناء
- Android Studio حديث وJDK 17.
- Android SDK Platform 36.
- Android 7.0 / API 24 أو أحدث.
- افتح مجلد المشروع ثم نفّذ Build > Make Project.

## التحقق
تم فحص ملفات XML وربط الموارد والتحقق من بنية ZIP. لم يتم تنفيذ Gradle Build أو اختبار فعلي على هاتف في بيئة الإنشاء الحالية لعدم توفر Android SDK وGradle. هذا مصدر تطوير وليس APK جاهزًا للنشر.

## Live Photo (v0.9.0)
- LIVE PHOTO captures a full-resolution still and a 3-second MP4 clip.
- The MP4 is embedded after the JPEG EOI marker with Google Camera Motion Photo XMP metadata (`GCamera:MotionPhoto`, `GCamera:MicroVideoOffset`).
- Output is a single `.jpg` in `Pictures/AROSTER CAMM/Live Photos`; compatible Motion Photo viewers can play the embedded clip.
- CameraX Recorder does not expose a circular pre-shutter video buffer. Therefore the 3-second clip starts at the shutter event; it is a standards-based Android Motion Photo, but does not reproduce Apple's exact 1.5s-before/1.5s-after timing or Apple's proprietary Live Photo pairing metadata.


## Live Photo Pre/Post Roll (v1.0.0)
تم تعديل Live Photo لتستخدم مخزن إطارات دائريًا من ImageAnalysis: 1.5 ثانية قبل ضغط زر التصوير، ثم التقاط الصورة الثابتة، ثم انتظار 1.5 ثانية بعد الضغط. تُجمع الإطارات وتُشفّر إلى MP4 H.264 ثم تُضمّن داخل JPEG ببيانات Google Motion Photo XMP، مع ضبط Presentation Timestamp عند 1.5 ثانية. يتطلب ذلك استمرار ImageAnalysis؛ إذا لم يدعم الجهاز ربط التحليل مع الكاميرا والفيديو معًا فلن يتوفر التسجيل المسبق. جودة مقطع الحركة أقل من الصورة الثابتة ويعتمد معدل الإطارات على أداء الجهاز. لم يتم تنفيذ Android Build أو اختبار فعلي على جهاز في بيئة الإنشاء.
