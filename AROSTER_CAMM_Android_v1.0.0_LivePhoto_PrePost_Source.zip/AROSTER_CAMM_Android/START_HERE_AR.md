# AROSTER CAMM v0.9.0

افتح المشروع في Android Studio ثم نفّذ Sync Project with Gradle Files وبعدها Build > Make Project.

## Live Photo
فعّل زر LIVE PHOTO من شاشة الكاميرا ثم اضغط زر التصوير. التطبيق يلتقط صورة ثابتة ويسجل مقطع MP4 مدته 3 ثوانٍ، ثم يدمج الفيديو داخل ملف JPEG واحد باستخدام بيانات Google Motion Photo XMP. ستجد الصور في:

`Pictures/AROSTER CAMM/Live Photos`

لازم تستخدم معرضًا يدعم Google Motion Photos لتشغيل الحركة. ملحوظة تقنية: المقطع يبدأ عند لحظة الضغط، لأن CameraX Recorder لا يوفّر buffer فيديو دائريًا قبل الضغط؛ لذلك لا يطابق توقيت Apple Live Photos حرفيًا.

الحد الأدنى للنظام Android 7.0 (API 24). لم يتم بناء APK أو اختبار التطبيق على جهاز فعلي في بيئة إعداد الملفات.


## Live Photo Pre/Post Roll (v1.0.0)
تم تعديل Live Photo لتستخدم مخزن إطارات دائريًا من ImageAnalysis: 1.5 ثانية قبل ضغط زر التصوير، ثم التقاط الصورة الثابتة، ثم انتظار 1.5 ثانية بعد الضغط. تُجمع الإطارات وتُشفّر إلى MP4 H.264 ثم تُضمّن داخل JPEG ببيانات Google Motion Photo XMP، مع ضبط Presentation Timestamp عند 1.5 ثانية. يتطلب ذلك استمرار ImageAnalysis؛ إذا لم يدعم الجهاز ربط التحليل مع الكاميرا والفيديو معًا فلن يتوفر التسجيل المسبق. جودة مقطع الحركة أقل من الصورة الثابتة ويعتمد معدل الإطارات على أداء الجهاز. لم يتم تنفيذ Android Build أو اختبار فعلي على جهاز في بيئة الإنشاء.
