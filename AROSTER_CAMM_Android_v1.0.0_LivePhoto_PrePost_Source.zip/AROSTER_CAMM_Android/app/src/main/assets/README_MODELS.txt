AROSTER CAMM 0.7.0 model notes

Portrait segmentation and face detection use ML Kit SDK dependencies.
Optional super-resolution model: sr_model.tflite
Expected contract: input [1,128,128,3], output [1,256,256,3], float RGB in 0..1. No compatible validated model is bundled.
No RIFE/optical-flow model is bundled. VIDEO LAB is a Media3 colour/crop pass with limited gyro-guided roll correction only.
Panorama is horizontal stitching, not full spherical/equirectangular 360 capture.
