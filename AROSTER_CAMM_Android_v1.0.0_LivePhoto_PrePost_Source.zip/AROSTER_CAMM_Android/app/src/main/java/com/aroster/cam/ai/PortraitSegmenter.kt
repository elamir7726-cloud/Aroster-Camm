package com.aroster.cam.ai

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.SegmentationMask
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions
import com.google.android.gms.tasks.Tasks
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit
import kotlin.math.max

/**
 * On-device ML Kit selfie segmentation for a still-photo portrait effect.
 * ML Kit's bundled model means no separately downloaded .tflite asset is required.
 */
class PortraitSegmenter : AutoCloseable {
    private val segmenter = Segmentation.getClient(
        SelfieSegmenterOptions.Builder()
            .setDetectorMode(SelfieSegmenterOptions.SINGLE_IMAGE_MODE)
            .build()
    )

    val isAvailable: Boolean get() = true

    /** Returns a new bitmap with a softly feathered foreground and blurred background. */
    fun blurBackground(src: Bitmap): Bitmap {
        require(src.width >= 256 && src.height >= 256) {
            "صورة Portrait لازم تكون 256×256 على الأقل"
        }
        // Keep the AI working bitmap bounded to protect RAM on older phones, then
        // scale the finished portrait back to the captured image dimensions.
        val working = if (max(src.width, src.height) > MAX_WORKING_SIDE) {
            val scale = MAX_WORKING_SIDE.toFloat() / max(src.width, src.height)
            Bitmap.createScaledBitmap(
                src,
                max(256, (src.width * scale).toInt()),
                max(256, (src.height * scale).toInt()),
                true
            )
        } else src
        try {
            val segmentation = Tasks.await(
                segmenter.process(InputImage.fromBitmap(working, 0)),
                30,
                TimeUnit.SECONDS
            )
            val processed = composePortrait(working, segmentation)
            if (working === src) return processed
            return try {
                Bitmap.createScaledBitmap(processed, src.width, src.height, true)
            } finally {
                processed.recycle()
            }
        } finally {
            if (working !== src) working.recycle()
        }
    }

    private fun composePortrait(src: Bitmap, mask: SegmentationMask): Bitmap {
        val width = src.width
        val height = src.height
        val maskWidth = mask.width
        val maskHeight = mask.height
        val probabilities = mask.buffer.duplicate().order(ByteOrder.nativeOrder())
        probabilities.rewind()

        val foreground = IntArray(width * height)
        src.getPixels(foreground, 0, width, 0, 0, width, height)

        val small = Bitmap.createScaledBitmap(
            src,
            max(1, width / BLUR_SCALE),
            max(1, height / BLUR_SCALE),
            true
        )
        val blurred = Bitmap.createScaledBitmap(small, width, height, true)
        if (small !== blurred) small.recycle()
        val background = IntArray(width * height)
        blurred.getPixels(background, 0, width, 0, 0, width, height)
        blurred.recycle()

        val output = IntArray(width * height)
        for (y in 0 until height) {
            val maskY = (y.toLong() * maskHeight / height).toInt().coerceIn(0, maskHeight - 1)
            for (x in 0 until width) {
                val maskX = (x.toLong() * maskWidth / width).toInt().coerceIn(0, maskWidth - 1)
                val maskIndex = maskY * maskWidth + maskX
                val byteIndex = maskIndex * java.lang.Float.BYTES
                val confidence = if (byteIndex + java.lang.Float.BYTES <= probabilities.limit()) {
                    probabilities.getFloat(byteIndex)
                } else 0f

                // Feather the mask edge to avoid a hard cutout around hair and shoulders.
                val alpha = ((confidence - EDGE_LOW) / (EDGE_HIGH - EDGE_LOW)).coerceIn(0f, 1f)
                val index = y * width + x
                output[index] = blend(background[index], foreground[index], alpha)
            }
        }
        return Bitmap.createBitmap(output, width, height, Bitmap.Config.ARGB_8888)
    }

    private fun blend(background: Int, foreground: Int, foregroundAlpha: Float): Int {
        val a = foregroundAlpha
        val b = 1f - a
        val r = (((Color.red(background) * b) + (Color.red(foreground) * a)).toInt()).coerceIn(0, 255)
        val g = (((Color.green(background) * b) + (Color.green(foreground) * a)).toInt()).coerceIn(0, 255)
        val blue = (((Color.blue(background) * b) + (Color.blue(foreground) * a)).toInt()).coerceIn(0, 255)
        return Color.rgb(r, g, blue)
    }

    override fun close() {
        segmenter.close()
    }

    companion object {
        private const val BLUR_SCALE = 18
        private const val EDGE_LOW = 0.35f
        private const val EDGE_HIGH = 0.68f
        private const val MAX_WORKING_SIDE = 1920
    }
}
