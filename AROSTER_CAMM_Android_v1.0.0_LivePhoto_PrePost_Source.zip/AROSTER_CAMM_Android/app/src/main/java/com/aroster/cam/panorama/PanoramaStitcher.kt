package com.aroster.cam.panorama

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * Lightweight on-device horizontal panorama assembler.
 * It estimates horizontal overlap between consecutive frames and feathers the seam.
 * This is a cylindrical-style panorama, not a feature-complete spherical projection.
 */
object PanoramaStitcher {
    data class Result(val file: File, val width: Int, val height: Int, val framesUsed: Int)

    fun stitch(inputDir: File, outputFile: File, maxSide: Int = 1280): Result {
        val files = inputDir.listFiles { f -> f.isFile && f.extension.equals("jpg", true) }
            ?.sortedBy { it.name } ?: emptyList()
        require(files.size >= 3) { "محتاج 3 صور على الأقل للبانوراما" }

        val frames = files.map { loadScaled(it, maxSide) }
        var composite = frames.first()
        var previous = frames.first()
        try {
            for (index in 1 until frames.size) {
                val current = frames[index]
                val normalized = if (current.height != previous.height) {
                    Bitmap.createScaledBitmap(current, max(1, current.width * previous.height / current.height), previous.height, true)
                } else current
                val overlap = estimateOverlap(previous, normalized)
                val xStart = (composite.width - overlap).coerceAtLeast(0)
                val newWidth = xStart + normalized.width
                val joined = Bitmap.createBitmap(newWidth, composite.height, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(joined)
                val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
                canvas.drawBitmap(composite, 0f, 0f, paint)
                canvas.drawBitmap(normalized, xStart.toFloat(), 0f, paint)

                val oldRow = IntArray(overlap)
                val newRow = IntArray(overlap)
                val blended = IntArray(overlap)
                val oldX = composite.width - overlap
                for (y in 0 until joined.height) {
                    composite.getPixels(oldRow, 0, overlap, oldX, y, overlap, 1)
                    normalized.getPixels(newRow, 0, overlap, 0, y, overlap, 1)
                    for (x in 0 until overlap) {
                        val t = x.toFloat() / max(1, overlap - 1)
                        blended[x] = mix(oldRow[x], newRow[x], t)
                    }
                    joined.setPixels(blended, 0, overlap, xStart, y, overlap, 1)
                }

                if (composite !== frames.first()) composite.recycle()
                composite = joined
                if (normalized !== current) normalized.recycle()
                if (previous !== frames.first() && previous !== current && !previous.isRecycled) previous.recycle()
                previous = current
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { stream ->
                check(composite.compress(Bitmap.CompressFormat.JPEG, 94, stream)) { "تعذر حفظ ملف البانوراما" }
            }
            return Result(outputFile, composite.width, composite.height, files.size)
        } finally {
            val unique = (frames + listOf(composite, previous)).distinctBy { System.identityHashCode(it) }
            unique.forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    private fun loadScaled(file: File, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "صورة غير صالحة: ${file.name}" }
        var sample = 1
        while (max(bounds.outWidth / (sample * 2), bounds.outHeight / (sample * 2)) >= maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: throw IllegalStateException("تعذر قراءة ${file.name}")
        val scale = min(1f, maxSide.toFloat() / max(decoded.width, decoded.height))
        if (scale >= 0.999f) return decoded
        val scaled = Bitmap.createScaledBitmap(decoded, max(1, (decoded.width * scale).toInt()), max(1, (decoded.height * scale).toInt()), true)
        if (scaled !== decoded) decoded.recycle()
        return scaled
    }

    private fun estimateOverlap(a: Bitmap, b: Bitmap): Int {
        val width = min(a.width, b.width)
        val height = min(a.height, b.height)
        val minOverlap = (width * 0.22f).toInt().coerceAtLeast(24)
        val maxOverlap = (width * 0.78f).toInt().coerceAtMost(width - 8)
        val aRow = IntArray(a.width)
        val bRow = IntArray(b.width)
        var bestOverlap = (width * 0.42f).toInt().coerceIn(minOverlap, maxOverlap)
        var bestScore = -2.0
        val yStep = max(4, height / 55)
        val xStep = max(3, width / 90)
        for (overlap in minOverlap..maxOverlap step 3) {
            var sumA = 0.0
            var sumB = 0.0
            var sumAA = 0.0
            var sumBB = 0.0
            var sumAB = 0.0
            var count = 0
            val leftA = width - overlap
            for (y in height / 8 until height * 7 / 8 step yStep) {
                a.getPixels(aRow, 0, a.width, 0, y, a.width, 1)
                b.getPixels(bRow, 0, b.width, 0, y, b.width, 1)
                for (x in 0 until overlap step xStep) {
                    val va = luminance(aRow[a.width - overlap + x])
                    val vb = luminance(bRow[x])
                    sumA += va; sumB += vb
                    sumAA += va * va; sumBB += vb * vb; sumAB += va * vb
                    count++
                }
            }
            if (count < 8) continue
            val cov = sumAB - sumA * sumB / count
            val varA = sumAA - sumA * sumA / count
            val varB = sumBB - sumB * sumB / count
            val score = cov / sqrt(max(1.0, varA * varB))
            if (score > bestScore) {
                bestScore = score
                bestOverlap = overlap
            }
        }
        return bestOverlap.coerceIn(minOverlap, maxOverlap)
    }

    private fun luminance(c: Int): Double =
        0.2126 * ((c shr 16) and 0xff) + 0.7152 * ((c shr 8) and 0xff) + 0.0722 * (c and 0xff)

    private fun mix(a: Int, b: Int, t: Float): Int {
        val inv = 1f - t
        val r = ((((a shr 16) and 255) * inv) + (((b shr 16) and 255) * t)).toInt().coerceIn(0, 255)
        val g = ((((a shr 8) and 255) * inv) + (((b shr 8) and 255) * t)).toInt().coerceIn(0, 255)
        val bl = (((a and 255) * inv) + ((b and 255) * t)).toInt().coerceIn(0, 255)
        return (0xff shl 24) or (r shl 16) or (g shl 8) or bl
    }
}
