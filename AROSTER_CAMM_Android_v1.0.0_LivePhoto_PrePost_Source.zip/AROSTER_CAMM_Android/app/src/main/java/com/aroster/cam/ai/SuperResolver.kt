package com.aroster.cam.ai

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter

/**
 * Optional tiled 2x super-resolution.
 * Model contract: input [1, 128, 128, 3], output [1, 256, 256, 3], float RGB in 0..1.
 * The model must match this contract exactly before this feature is enabled.
 */
class SuperResolver(context: Context) : AutoCloseable {
    private val interpreter: Interpreter? = try {
        ModelLoader.mapAsset(context, MODEL)?.let {
            Interpreter(it, Interpreter.Options().setNumThreads(4))
        }
    } catch (_: Exception) {
        null
    }

    val isAvailable: Boolean get() = interpreter != null

    fun upscale2x(src: Bitmap): Bitmap {
        val model = interpreter ?: return src
        val width = src.width
        val height = src.height
        val srcPixels = IntArray(width * height)
        src.getPixels(srcPixels, 0, width, 0, 0, width, height)

        val outWidth = width * 2
        val outHeight = height * 2
        val outPixels = IntArray(outWidth * outHeight)
        val input = Array(1) { Array(TILE) { Array(TILE) { FloatArray(3) } } }
        val output = Array(1) { Array(TILE * 2) { Array(TILE * 2) { FloatArray(3) } } }

        var top = 0
        while (top < height) {
            var left = 0
            while (left < width) {
                for (y in 0 until TILE) {
                    val sourceY = (top + y).coerceAtMost(height - 1)
                    for (x in 0 until TILE) {
                        val sourceX = (left + x).coerceAtMost(width - 1)
                        val color = srcPixels[sourceY * width + sourceX]
                        val pixel = input[0][y][x]
                        pixel[0] = ((color shr 16) and 0xFF) / 255f
                        pixel[1] = ((color shr 8) and 0xFF) / 255f
                        pixel[2] = (color and 0xFF) / 255f
                    }
                }

                model.run(input, output)
                val copyWidth = minOf(TILE, width - left)
                val copyHeight = minOf(TILE, height - top)
                for (y in 0 until copyHeight * 2) {
                    for (x in 0 until copyWidth * 2) {
                        val pixel = output[0][y][x]
                        outPixels[(top * 2 + y) * outWidth + left * 2 + x] =
                            (0xFF shl 24) or (toByte(pixel[0]) shl 16) or
                                (toByte(pixel[1]) shl 8) or toByte(pixel[2])
                    }
                }
                left += TILE
            }
            top += TILE
        }
        return Bitmap.createBitmap(outPixels, outWidth, outHeight, Bitmap.Config.ARGB_8888)
    }

    private fun toByte(value: Float): Int = (value.coerceIn(0f, 1f) * 255f + 0.5f).toInt()

    override fun close() {
        interpreter?.close()
    }

    companion object {
        const val MODEL = "sr_model.tflite"
        private const val TILE = 128
    }
}
