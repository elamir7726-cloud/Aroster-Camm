package com.aroster.cam.ai

import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions

/**
 * بيحلل كل فريم ويقول إمتى الوجه جاهز: ابتسامة + عين مفتوحة، ومستقر لفترة قصيرة.
 * بيقفل الـ ImageProxy بنفسه في كل الحالات.
 */
class SmartShotAnalyzer(private val onReady: () -> Unit) : AutoCloseable {

    @Volatile
    var enabled: Boolean = false

    private var stableFrames = 0
    private var lastShotAt = 0L

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .build()
    )

    /** بيتنادى من thread التحليل */
    @OptIn(ExperimentalGetImage::class)
    fun analyze(proxy: ImageProxy) {
        try {
            val media = proxy.image
            if (!enabled || media == null) {
                proxy.close()
                return
            }
            val input = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
            detector.process(input)
                .addOnSuccessListener { faces -> evaluate(faces) }
                .addOnCompleteListener { proxy.close() }
        } catch (_: Exception) {
            proxy.close()
        }
    }

    // ML Kit بيرجّع النتيجة على الـ main thread
    private fun evaluate(faces: List<Face>) {
        val face = faces.maxByOrNull { it.boundingBox.width() * it.boundingBox.height() }
        val good = face != null &&
            (face.smilingProbability ?: 0f) > 0.7f &&
            (face.leftEyeOpenProbability ?: 0f) > 0.8f &&
            (face.rightEyeOpenProbability ?: 0f) > 0.8f

        stableFrames = if (good) stableFrames + 1 else 0

        val now = System.currentTimeMillis()
        if (stableFrames >= STABLE_FRAMES && now - lastShotAt > COOLDOWN_MS) {
            stableFrames = 0
            lastShotAt = now
            onReady()
        }
    }

    override fun close() {
        detector.close()
    }

    companion object {
        private const val STABLE_FRAMES = 5
        private const val COOLDOWN_MS = 3000L
    }
}
