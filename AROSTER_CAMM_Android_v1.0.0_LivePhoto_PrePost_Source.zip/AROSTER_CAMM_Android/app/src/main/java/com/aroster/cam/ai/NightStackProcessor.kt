package com.aroster.cam.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Lightweight multi-frame night fusion for mid-range phones.
 * The burst is aligned with a coarse global translation, then averaged with a
 * reference-frame ghosting guard. It is computational photography, not a neural model.
 */
object NightStackProcessor {
    fun merge(inputFiles: List<File>, outputFile: File, maxSide: Int = 2200): File {
        require(inputFiles.size >= 3) { "وضع Night يحتاج 3 لقطات على الأقل" }
        val frames = ArrayList<Bitmap>(inputFiles.size)
        try {
            inputFiles.forEach { frames += loadOrientedScaled(it, maxSide) }
            val reference = frames.first()
            val width = reference.width
            val height = reference.height
            val shifts = frames.mapIndexed { index, bitmap ->
                if (index == 0) 0 to 0 else estimateShift(reference, bitmap)
            }

            val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val refRow = IntArray(width)
            val rowBuffers = Array(frames.size) { IntArray(width) }
            val outRow = IntArray(width)

            for (y in 0 until height) {
                reference.getPixels(refRow, 0, width, 0, y, width, 1)
                for (i in frames.indices) {
                    val (dx, dy) = shifts[i]
                    val sourceY = y + dy
                    if (sourceY in 0 until height) {
                        val startX = max(0, -dx)
                        val endX = min(width, width - dx)
                        if (endX > startX) {
                            frames[i].getPixels(
                                rowBuffers[i], startX, width,
                                startX + dx, sourceY, endX - startX, 1
                            )
                        }
                    }
                }

                for (x in 0 until width) {
                    val base = refRow[x]
                    val baseR = (base shr 16) and 255
                    val baseG = (base shr 8) and 255
                    val baseB = base and 255
                    val baseY = luminance(baseR, baseG, baseB)
                    var sumR = baseR.toFloat()
                    var sumG = baseG.toFloat()
                    var sumB = baseB.toFloat()
                    var count = 1f

                    for (i in 1 until frames.size) {
                        val (dx, dy) = shifts[i]
                        val sx = x + dx
                        val sy = y + dy
                        if (sx !in 0 until width || sy !in 0 until height) continue
                        val c = rowBuffers[i][x]
                        val r = (c shr 16) and 255
                        val g = (c shr 8) and 255
                        val b = c and 255
                        val delta = abs(luminance(r, g, b) - baseY)
                        // Large local differences are likely moving objects or alignment errors.
                        if (delta > 48f) continue
                        sumR += r
                        sumG += g
                        sumB += b
                        count += 1f
                    }
                    val r = (sumR / count).toInt().coerceIn(0, 255)
                    val g = (sumG / count).toInt().coerceIn(0, 255)
                    val b = (sumB / count).toInt().coerceIn(0, 255)
                    outRow[x] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
                }
                output.setPixels(outRow, 0, width, 0, y, width, 1)
            }

            outputFile.parentFile?.mkdirs()
            FileOutputStream(outputFile).use { stream ->
                check(output.compress(Bitmap.CompressFormat.JPEG, 96, stream)) { "تعذر حفظ صورة Night" }
            }
            output.recycle()
            return outputFile
        } finally {
            frames.forEach { if (!it.isRecycled) it.recycle() }
        }
    }

    private fun loadOrientedScaled(file: File, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "صورة تالفة: ${file.name}" }
        var sample = 1
        while (max(bounds.outWidth / (sample * 2), bounds.outHeight / (sample * 2)) >= maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: throw IllegalStateException("تعذر قراءة ${file.name}")

        val scale = min(1f, maxSide.toFloat() / max(decoded.width, decoded.height))
        val scaled = if (scale < 0.999f) Bitmap.createScaledBitmap(
            decoded, max(1, (decoded.width * scale).toInt()), max(1, (decoded.height * scale).toInt()), true
        ) else decoded
        if (scaled !== decoded) decoded.recycle()

        val orientation = runCatching { ExifInterface(file).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        ) }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return scaled
        val matrix = Matrix().apply { postRotate(degrees) }
        val rotated = Bitmap.createBitmap(scaled, 0, 0, scaled.width, scaled.height, matrix, true)
        if (rotated !== scaled) scaled.recycle()
        return rotated
    }

    /** Returns the shift to sample from candidate so it aligns with reference. */
    private fun estimateShift(reference: Bitmap, candidate: Bitmap): Pair<Int, Int> {
        val smallWidth = min(320, reference.width)
        val smallHeight = max(1, reference.height * smallWidth / reference.width)
        val refSmall = Bitmap.createScaledBitmap(reference, smallWidth, smallHeight, true)
        val canSmall = Bitmap.createScaledBitmap(candidate, smallWidth, smallHeight, true)
        try {
            val refPixels = IntArray(smallWidth * smallHeight)
            val canPixels = IntArray(smallWidth * smallHeight)
            refSmall.getPixels(refPixels, 0, smallWidth, 0, 0, smallWidth, smallHeight)
            canSmall.getPixels(canPixels, 0, smallWidth, 0, 0, smallWidth, smallHeight)
            val maxDx = min(12, smallWidth / 12)
            val maxDy = min(10, smallHeight / 12)
            var bestDx = 0
            var bestDy = 0
            var bestScore = Double.MAX_VALUE
            for (dy in -maxDy..maxDy) {
                for (dx in -maxDx..maxDx) {
                    var sumDiff = 0.0
                    var sumDelta = 0.0
                    var count = 0
                    for (y in 12 until smallHeight - 12 step 5) {
                        val cy = y + dy
                        if (cy !in 0 until smallHeight) continue
                        for (x in 12 until smallWidth - 12 step 5) {
                            val cx = x + dx
                            if (cx !in 0 until smallWidth) continue
                            val a = gray(refPixels[y * smallWidth + x])
                            val b = gray(canPixels[cy * smallWidth + cx])
                            sumDelta += (a - b)
                            sumDiff += abs(a - b).toDouble()
                            count++
                        }
                    }
                    if (count == 0) continue
                    val meanDelta = sumDelta / count
                    // Exposure can drift slightly; subtract the global brightness offset.
                    val score = max(0.0, sumDiff / count - abs(meanDelta) * 0.45)
                    if (score < bestScore) {
                        bestScore = score
                        bestDx = dx
                        bestDy = dy
                    }
                }
            }
            val scaleX = reference.width.toFloat() / smallWidth
            val scaleY = reference.height.toFloat() / smallHeight
            return (bestDx * scaleX).toInt() to (bestDy * scaleY).toInt()
        } finally {
            if (refSmall !== reference && !refSmall.isRecycled) refSmall.recycle()
            if (canSmall !== candidate && canSmall !== refSmall && !canSmall.isRecycled) canSmall.recycle()
        }
    }

    private fun gray(color: Int): Float =
        0.2126f * ((color shr 16) and 255) + 0.7152f * ((color shr 8) and 255) + 0.0722f * (color and 255)

    private fun luminance(r: Int, g: Int, b: Int): Float =
        0.2126f * r + 0.7152f * g + 0.0722f * b
}
