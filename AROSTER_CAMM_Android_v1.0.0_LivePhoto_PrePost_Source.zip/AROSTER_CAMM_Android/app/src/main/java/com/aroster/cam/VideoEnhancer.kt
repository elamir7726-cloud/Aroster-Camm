package com.aroster.cam

import android.content.Context
import android.graphics.Matrix
import android.net.Uri
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Contrast
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.RgbAdjustment
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import java.io.File
import kotlin.math.abs

/**
 * Device-local video finishing pass.
 * Applies a restrained cinema grade and optional gyro-guided rotational correction.
 * The correction is not a neural/optical-flow model; capture-time camera EIS remains device-dependent.
 */
@OptIn(UnstableApi::class)
class VideoEnhancer(private val context: Context) {
    fun export(
        source: Uri,
        output: File,
        gyroLog: File?,
        onComplete: (File) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        val samples = readGyro(gyroLog)
        val rotationEffect = MatrixTransformation { presentationTimeUs ->
            val correction = correctionDegrees(samples, presentationTimeUs)
            Matrix().apply {
                // Normalized device coordinates: origin is the frame centre.
                postScale(1.065f, 1.065f)
                if (abs(correction) > 0.01f) postRotate(correction)
            }
        }
        val warmCoolGrade = RgbAdjustment.Builder()
            .setRedScale(1.045f)
            .setGreenScale(1.0f)
            .setBlueScale(0.975f)
            .build()
        val effects = Effects(
            emptyList(),
            listOf(Contrast(0.12f), warmCoolGrade, rotationEffect)
        )
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(source))
            .setEffects(effects)
            .build()

        val transformer = Transformer.Builder(context)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: androidx.media3.transformer.Composition, exportResult: ExportResult) {
                    if (output.exists() && output.length() > 0L) onComplete(output)
                    else onError(IllegalStateException("ملف الفيديو الناتج فارغ"))
                }

                override fun onError(
                    composition: androidx.media3.transformer.Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    output.delete()
                    onError(exportException)
                }
            })
            .build()
        try {
            output.parentFile?.mkdirs()
            transformer.start(edited, output.absolutePath)
        } catch (error: Exception) {
            output.delete()
            onError(error)
        }
    }

    private data class GyroSample(val timeUs: Long, val rollRadians: Float)

    private fun readGyro(file: File?): List<GyroSample> {
        if (file == null || !file.isFile) return emptyList()
        return runCatching {
            file.useLines { lines ->
                lines.mapNotNull { line ->
                    val parts = line.split(',')
                    if (parts.size != 2) null else {
                        val t = parts[0].toLongOrNull()
                        val r = parts[1].toFloatOrNull()
                        if (t == null || r == null) null else GyroSample(t, r)
                    }
                }.take(30000).toList()
            }
        }.getOrDefault(emptyList())
    }

    private fun correctionDegrees(samples: List<GyroSample>, timeUs: Long): Float {
        if (samples.size < 5) return 0f
        var low = 0
        var high = samples.lastIndex
        while (low <= high) {
            val mid = (low + high) ushr 1
            if (samples[mid].timeUs < timeUs) low = mid + 1 else high = mid - 1
        }
        val nearest = low.coerceIn(0, samples.lastIndex)
        val center = samples[nearest].rollRadians
        val windowUs = 180_000L
        var sum = 0.0
        var count = 0
        var i = nearest
        while (i >= 0 && abs(timeUs - samples[i].timeUs) <= windowUs) {
            sum += samples[i].rollRadians; count++; i--
        }
        i = nearest + 1
        while (i < samples.size && abs(samples[i].timeUs - timeUs) <= windowUs) {
            sum += samples[i].rollRadians; count++; i++
        }
        if (count == 0) return 0f
        val smooth = (sum / count).toFloat()
        return Math.toDegrees((smooth - center).toDouble()).toFloat().coerceIn(-3.0f, 3.0f)
    }
}
