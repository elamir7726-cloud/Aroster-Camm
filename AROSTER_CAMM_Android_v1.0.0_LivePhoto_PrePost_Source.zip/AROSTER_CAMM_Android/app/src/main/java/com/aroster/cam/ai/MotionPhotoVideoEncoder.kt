package com.aroster.cam.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Rect
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import kotlin.math.max
import kotlin.math.min

/** Encodes buffered JPEG frames as a short H.264 MP4 suitable for Motion Photo packaging. */
object MotionPhotoVideoEncoder {
    private const val FPS = 12
    private const val FRAME_INTERVAL_MS = 1_000L / FPS

    fun encode(frames: List<MotionPhotoBuffer.Frame>, output: File) {
        require(frames.size >= 12) { "Not enough buffered frames for a Live Photo" }
        val sorted = frames.sortedBy { it.timestampMs }
        val start = sorted.first().timestampMs
        val end = sorted.last().timestampMs
        require(end - start >= 2_700L) { "The 3-second motion window is incomplete" }

        val selected = ArrayList<MotionPhotoBuffer.Frame>(36)
        for (i in 0 until 36) {
            val target = start + (i * 3_000L / 35L)
            selected += sorted.minBy { kotlin.math.abs(it.timestampMs - target) }
        }

        val firstBitmap = BitmapFactory.decodeByteArray(selected.first().jpeg, 0, selected.first().jpeg.size)
            ?: throw IllegalStateException("Could not decode first buffered frame")
        val width = if (firstBitmap.width >= firstBitmap.height) 640 else 480
        val height = if (firstBitmap.width >= firstBitmap.height) 480 else 640
        firstBitmap.recycle()

        val format = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 1_600_000)
            setInteger(MediaFormat.KEY_FRAME_RATE, FPS)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        var muxer: MediaMuxer? = null
        var input: Surface? = null
        var trackIndex = -1
        var muxerStarted = false
        val info = MediaCodec.BufferInfo()
        try {
            codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            input = codec.createInputSurface()
            muxer = MediaMuxer(output.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
            codec.start()
            val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)

            for (frame in selected) {
                val bitmap = BitmapFactory.decodeByteArray(frame.jpeg, 0, frame.jpeg.size)
                    ?: throw IllegalStateException("Could not decode buffered frame")
                val canvas: Canvas = input.lockCanvas(null)
                try {
                    canvas.drawColor(Color.BLACK)
                    val source = centerCropSourceRect(bitmap.width, bitmap.height, width, height)
                    canvas.drawBitmap(bitmap, source, Rect(0, 0, width, height), paint)
                } finally {
                    input.unlockCanvasAndPost(canvas)
                    bitmap.recycle()
                }
                drain(codec, muxer, info, false) { index -> trackIndex = index; muxerStarted = true }
                Thread.sleep(FRAME_INTERVAL_MS)
            }
            codec.signalEndOfInputStream()
            var done = false
            while (!done) done = drain(codec, muxer, info, true) { index -> trackIndex = index; muxerStarted = true }
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            codec.release()
            input?.release()
            if (muxerStarted) try { muxer?.stop() } catch (_: Exception) { }
            muxer?.release()
        }
    }

    private fun drain(codec: MediaCodec, muxer: MediaMuxer, info: MediaCodec.BufferInfo,
                      endOfStream: Boolean, onTrack: (Int) -> Unit): Boolean {
        var eos = false
        while (true) {
            when (val index = codec.dequeueOutputBuffer(info, if (endOfStream) 10_000L else 0L)) {
                MediaCodec.INFO_TRY_AGAIN_LATER -> if (!endOfStream) return false else return eos
                MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> onTrack(muxer.addTrack(codec.outputFormat)).also { muxer.start() }
                MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED -> Unit
                else -> if (index >= 0) {
                    val buffer: ByteBuffer = codec.getOutputBuffer(index) ?: throw IllegalStateException("Missing encoder output")
                    if (info.size > 0) {
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            buffer.position(info.offset)
                            buffer.limit(info.offset + info.size)
                            muxer.writeSampleData(0, buffer, info)
                        }
                    }
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) eos = true
                    codec.releaseOutputBuffer(index, false)
                    if (eos) return true
                }
            }
        }
    }

    private fun centerCropSourceRect(bw: Int, bh: Int, outW: Int, outH: Int): Rect {
        val sourceAspect = bw.toFloat() / bh
        val outputAspect = outW.toFloat() / outH
        return if (sourceAspect > outputAspect) {
            val cropW = (bh * outputAspect).toInt().coerceAtLeast(1)
            val left = (bw - cropW) / 2
            Rect(left, 0, left + cropW, bh)
        } else {
            val cropH = (bw / outputAspect).toInt().coerceAtLeast(1)
            val top = (bh - cropH) / 2
            Rect(0, top, bw, top + cropH)
        }
    }
}
