package com.aroster.cam.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream
import kotlin.math.max

/** Rolling RAM buffer for the 1.5 seconds immediately before the shutter. */
class MotionPhotoBuffer(
    private val maxFrames: Int = 42,
    private val minIntervalMs: Long = 75L,
    private val maxSide: Int = 640
) {
    data class Frame(val timestampMs: Long, val jpeg: ByteArray)
    private val frames = ArrayDeque<Frame>()
    @Volatile private var lastStoredAt = 0L

    /** Call before closing ImageProxy. */
    fun offer(proxy: ImageProxy) {
        val now = System.currentTimeMillis()
        if (now - lastStoredAt < minIntervalMs) return
        lastStoredAt = now
        val original = proxy.toBitmap()
        val scaled = scaleDown(original, maxSide)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.JPEG, 78, out)
        if (scaled !== original) scaled.recycle()
        original.recycle()
        synchronized(frames) {
            frames.addLast(Frame(now, out.toByteArray()))
            while (frames.size > maxFrames) frames.removeFirst()
        }
    }

    fun snapshot(fromMs: Long, toMs: Long): List<Frame> = synchronized(frames) {
        frames.filter { it.timestampMs in fromMs..toMs }
    }

    fun hasPreRoll(nowMs: Long, requiredMs: Long = 1_350L): Boolean = synchronized(frames) {
        frames.isNotEmpty() && frames.first().timestampMs <= nowMs - requiredMs
    }

    private fun scaleDown(bitmap: Bitmap, side: Int): Bitmap {
        val scale = side.toFloat() / max(bitmap.width, bitmap.height)
        if (scale >= 1f) return bitmap
        return Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1),
            (bitmap.height * scale).toInt().coerceAtLeast(1), true)
    }
}
