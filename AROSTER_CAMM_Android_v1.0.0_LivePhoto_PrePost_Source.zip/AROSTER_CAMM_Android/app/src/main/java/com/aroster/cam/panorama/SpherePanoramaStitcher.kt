package com.aroster.cam.panorama

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import androidx.exifinterface.media.ExifInterface
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Builds a full equirectangular Photo Sphere from images and the device-to-world
 * rotation matrix recorded for each exposure. The GPano XMP block lets compatible
 * gallery apps recognize the output as a spherical panorama.
 */
object SpherePanoramaStitcher {
    data class Frame(val file: File, val deviceToWorld: FloatArray)
    data class Result(val file: File, val width: Int, val height: Int, val frameCount: Int)

    fun stitch(frames: List<Frame>, outputFile: File, maxWidth: Int = 2048): Result {
        require(frames.size >= 18) { "لا توجد لقطات كافية لتكوين صورة 360°" }
        require(frames.all { it.file.isFile && it.deviceToWorld.size >= 9 }) { "بيانات اتجاه إحدى اللقطات غير مكتملة" }

        val width = maxWidth.coerceIn(1536, 3072)
        val height = width / 2
        val pixelCount = width * height
        val red = FloatArray(pixelCount)
        val green = FloatArray(pixelCount)
        val blue = FloatArray(pixelCount)
        val weights = FloatArray(pixelCount)

        // Approximate 66-degree horizontal field of view; the source is already EXIF-upright.
        val fxByFrame = HashMap<Int, Float>()
        val outputFrames = frames.size
        for ((frameIndex, frame) in frames.withIndex()) {
            val bitmap = loadScaledUpright(frame.file, 720)
            try {
                val w = bitmap.width
                val h = bitmap.height
                // Estimate focal length in pixels from the sensor's longer image dimension.
                // This keeps the narrower field of view correct after EXIF rotates a portrait capture.
                val focalPixels = fxByFrame.getOrPut(max(w, h)) {
                    max(w, h) / (2f * kotlin.math.tan(Math.toRadians(33.0)).toFloat())
                }
                val fx = focalPixels
                val fy = focalPixels // square pixel assumption; horizontal/vertical FOV follow image aspect ratio.
                val cx = (w - 1) / 2f
                val cy = (h - 1) / 2f
                val m = frame.deviceToWorld
                val row = IntArray(w)

                for (y in 0 until h) {
                    bitmap.getPixels(row, 0, w, 0, y, w, 1)
                    val cameraY = -(y - cy) / fy
                    for (x in 0 until w) {
                        val cameraX = (x - cx) / fx
                        // Back-camera optical axis is the device -Z axis.
                        val invLength = (1.0 / sqrt((cameraX * cameraX + cameraY * cameraY + 1f).toDouble())).toFloat()
                        val dx = cameraX * invLength
                        val dy = cameraY * invLength
                        val dz = -invLength

                        // Android rotation-vector matrix maps device coordinates into world coordinates.
                        val worldX = m[0] * dx + m[1] * dy + m[2] * dz
                        val worldY = m[3] * dx + m[4] * dy + m[5] * dz
                        val worldZ = m[6] * dx + m[7] * dy + m[8] * dz
                        val longitude = atan2(worldX, -worldZ)
                        val latitude = asin(worldY.coerceIn(-1f, 1f))
                        val px = ((longitude + PI.toFloat()) / (2f * PI.toFloat()) * width)
                        val py = ((PI.toFloat() / 2f - latitude) / PI.toFloat() * height)
                        val x0 = kotlin.math.floor(px).toInt()
                        val y0 = kotlin.math.floor(py).toInt().coerceIn(0, height - 1)
                        val tx = (px - kotlin.math.floor(px).toFloat()).coerceIn(0f, 1f)
                        val ty = (py - kotlin.math.floor(py).toFloat()).coerceIn(0f, 1f)
                        val color = row[x]
                        val r = ((color shr 16) and 255).toFloat()
                        val g = ((color shr 8) and 255).toFloat()
                        val b = (color and 255).toFloat()

                        // Feather toward the frame center to reduce visible seams between tiles.
                        val centerWeight = (invLength * invLength * invLength).coerceAtLeast(0.08f)
                        splat(x0, y0, tx, ty, centerWeight, r, g, b, width, height, red, green, blue, weights)
                    }
                }
            } finally {
                bitmap.recycle()
            }
        }

        val pixels = IntArray(pixelCount)
        for (i in 0 until pixelCount) {
            if (weights[i] > 0f) {
                val inv = 1f / weights[i]
                val r = (red[i] * inv).toInt().coerceIn(0, 255)
                val g = (green[i] * inv).toInt().coerceIn(0, 255)
                val b = (blue[i] * inv).toInt().coerceIn(0, 255)
                pixels[i] = (0xff shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        fillSmallGaps(pixels, weights, width, height)

        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        output.setPixels(pixels, 0, width, 0, 0, width, height)
        val jpegBytes = ByteArrayOutputStream().use { stream ->
            check(output.compress(Bitmap.CompressFormat.JPEG, 95, stream)) { "تعذر ترميز صورة 360°" }
            stream.toByteArray()
        }
        output.recycle()

        val tagged = injectGpanoXmp(jpegBytes, width, height)
        outputFile.parentFile?.mkdirs()
        FileOutputStream(outputFile).use { it.write(tagged) }
        return Result(outputFile, width, height, outputFrames)
    }

    private fun splat(
        x0: Int, y0: Int, tx: Float, ty: Float, baseWeight: Float,
        r: Float, g: Float, b: Float, width: Int, height: Int,
        red: FloatArray, green: FloatArray, blue: FloatArray, weights: FloatArray
    ) {
        val xA = ((x0 % width) + width) % width
        val xB = (xA + 1) % width
        val yA = y0.coerceIn(0, height - 1)
        val yB = (yA + 1).coerceAtMost(height - 1)
        add(xA, yA, baseWeight * (1f - tx) * (1f - ty), r, g, b, width, red, green, blue, weights)
        add(xB, yA, baseWeight * tx * (1f - ty), r, g, b, width, red, green, blue, weights)
        add(xA, yB, baseWeight * (1f - tx) * ty, r, g, b, width, red, green, blue, weights)
        add(xB, yB, baseWeight * tx * ty, r, g, b, width, red, green, blue, weights)
    }

    private fun add(
        x: Int, y: Int, weight: Float, r: Float, g: Float, b: Float, width: Int,
        red: FloatArray, green: FloatArray, blue: FloatArray, weights: FloatArray
    ) {
        if (weight <= 0.00001f) return
        val index = y * width + x
        red[index] += r * weight
        green[index] += g * weight
        blue[index] += b * weight
        weights[index] += weight
    }

    private fun fillSmallGaps(pixels: IntArray, weights: FloatArray, width: Int, height: Int) {
        // A few bounded diffusion passes fill tiny sampling holes without inventing large regions.
        repeat(5) {
            var filled = 0
            for (y in 1 until height - 1) {
                for (x in 0 until width) {
                    val index = y * width + x
                    if (weights[index] > 0f) continue
                    val left = y * width + (x - 1 + width) % width
                    val right = y * width + (x + 1) % width
                    val up = index - width
                    val down = index + width
                    var rr = 0; var gg = 0; var bb = 0; var count = 0
                    if (weights[left] > 0f) {
                        rr += (pixels[left] shr 16) and 255; gg += (pixels[left] shr 8) and 255; bb += pixels[left] and 255; count++
                    }
                    if (weights[right] > 0f) {
                        rr += (pixels[right] shr 16) and 255; gg += (pixels[right] shr 8) and 255; bb += pixels[right] and 255; count++
                    }
                    if (weights[up] > 0f) {
                        rr += (pixels[up] shr 16) and 255; gg += (pixels[up] shr 8) and 255; bb += pixels[up] and 255; count++
                    }
                    if (weights[down] > 0f) {
                        rr += (pixels[down] shr 16) and 255; gg += (pixels[down] shr 8) and 255; bb += pixels[down] and 255; count++
                    }
                    if (count >= 2) {
                        pixels[index] = (0xff shl 24) or ((rr / count) shl 16) or ((gg / count) shl 8) or (bb / count)
                        weights[index] = 0.0001f
                        filled++
                    }
                }
            }
            if (filled == 0) return
        }
        if (height > 2) {
            System.arraycopy(pixels, width, pixels, 0, width)
            System.arraycopy(pixels, (height - 2) * width, pixels, (height - 1) * width, width)
        }
    }

    private fun loadScaledUpright(file: File, maxSide: Int): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        require(bounds.outWidth > 0 && bounds.outHeight > 0) { "صورة غير صالحة: ${file.name}" }
        var sample = 1
        while (max(bounds.outWidth / (sample * 2), bounds.outHeight / (sample * 2)) >= maxSide) sample *= 2
        val decoded = BitmapFactory.decodeFile(file.absolutePath, BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }) ?: throw IllegalStateException("تعذر فتح ${file.name}")
        val scale = min(1f, maxSide.toFloat() / max(decoded.width, decoded.height))
        val scaled = if (scale < 0.999f) Bitmap.createScaledBitmap(
            decoded, max(1, (decoded.width * scale).toInt()), max(1, (decoded.height * scale).toInt()), true
        ) else decoded
        if (scaled !== decoded) decoded.recycle()

        val orientation = runCatching { ExifInterface(file).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        ) }.getOrDefault(ExifInterface.ORIENTATION_NORMAL)
        val degrees = when (orientation) {
            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
            else -> 0f
        }
        if (degrees == 0f) return scaled
        val matrix = Matrix().apply { postRotate(degrees) }
        val rotated = Bitmap.createBitmap(scaled, 0, 0, scaled.width, scaled.height, matrix, true)
        if (rotated !== scaled) scaled.recycle()
        return rotated
    }

    private fun injectGpanoXmp(jpeg: ByteArray, width: Int, height: Int): ByteArray {
        if (jpeg.size < 4 || jpeg[0] != 0xff.toByte() || jpeg[1] != 0xd8.toByte()) return jpeg
        val xmp = """
            <?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
            <x:xmpmeta xmlns:x="adobe:ns:meta/">
              <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
                <rdf:Description rdf:about=""
                  xmlns:GPano="http://ns.google.com/photos/1.0/panorama/"
                  GPano:UsePanoramaViewer="True"
                  GPano:ProjectionType="equirectangular"
                  GPano:PoseHeadingDegrees="0"
                  GPano:InitialViewHeadingDegrees="0"
                  GPano:InitialViewPitchDegrees="0"
                  GPano:InitialViewRollDegrees="0"
                  GPano:InitialHorizontalFOVDegrees="90"
                  GPano:FullPanoWidthPixels="$width"
                  GPano:FullPanoHeightPixels="$height"
                  GPano:CroppedAreaImageWidthPixels="$width"
                  GPano:CroppedAreaImageHeightPixels="$height"
                  GPano:CroppedAreaLeftPixels="0"
                  GPano:CroppedAreaTopPixels="0" />
              </rdf:RDF>
            </x:xmpmeta>
            <?xpacket end="w"?>
        """.trimIndent().toByteArray(Charsets.UTF_8)
        val header = "http://ns.adobe.com/xap/1.0/\u0000".toByteArray(Charsets.US_ASCII)
        val segmentLength = header.size + xmp.size + 2
        if (segmentLength > 65535) return jpeg
        val out = ByteArrayOutputStream(jpeg.size + segmentLength + 4)
        out.write(jpeg, 0, 2)
        out.write(0xff); out.write(0xe1)
        out.write((segmentLength shr 8) and 0xff); out.write(segmentLength and 0xff)
        out.write(header); out.write(xmp)
        out.write(jpeg, 2, jpeg.size - 2)
        return out.toByteArray()
    }
}
