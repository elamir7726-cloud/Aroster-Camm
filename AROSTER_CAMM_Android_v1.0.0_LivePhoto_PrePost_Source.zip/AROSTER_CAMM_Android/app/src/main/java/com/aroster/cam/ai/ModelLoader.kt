package com.aroster.cam.ai

import android.content.Context
import java.io.FileInputStream
import java.io.IOException
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel

object ModelLoader {
    fun hasAsset(context: Context, name: String): Boolean =
        try {
            context.assets.open(name).close()
            true
        } catch (e: IOException) {
            false
        }

    fun mapAsset(context: Context, name: String): MappedByteBuffer? =
        try {
            context.assets.openFd(name).use { fd ->
                FileInputStream(fd.fileDescriptor).channel.map(
                    FileChannel.MapMode.READ_ONLY, fd.startOffset, fd.declaredLength
                )
            }
        } catch (e: IOException) {
            null
        }
}
