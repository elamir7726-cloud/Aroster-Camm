package com.aroster.cam.ai

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.concurrent.TimeUnit
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/**
 * On-device still-photo finishing.
 * The pipeline deliberately favours natural skin and highlight retention over aggressive filters.
 * No generative relighting or neural super-resolution is claimed unless a compatible model is supplied.
 */
class PhotoPipeline(context: Context) : AutoCloseable {
    private val appContext = context.applicationContext
    private val superRes = SuperResolver(appContext)
    private val portrait = PortraitSegmenter()
    private val faceDetector: FaceDetector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
    )

    fun process(file: File, portraitOn: Boolean, cinematicOn: Boolean): ByteArray {
        var bitmap = loadOriented(file)
        try {
            if (portraitOn) {
                val previous = bitmap
                val segmented = runCatching { portrait.blurBackground(previous) }.getOrNull()
                if (segmented != null && segmented !== previous) {
                    bitmap = segmented
                    previous.recycle()
                }
            }

            // Face boxes let the grade protect skin from excessive split-toning and saturation shifts.
            val faces = detectFaces(bitmap)
            val previous = bitmap
            bitmap = finishPhoto(previous, faces, cinematicOn)
            previous.recycle()

            if (superRes.isAvailable && max(bitmap.width, bitmap.height) < SR_MAX_INPUT_SIDE) {
                val source = bitmap
                val upscaled = runCatching { superRes.upscale2x(source) }.getOrNull()
                if (upscaled != null && upscaled !== source) {
                    bitmap = upscaled
                    source.recycle()
                }
            }

            val output = ByteArrayOutputStream()
            if (!bitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, output)) {
                throw IllegalStateException("تعذر ترميز الصورة")
            }
            return output.toByteArray()
        } finally {
            if (!bitmap.isRecycled) bitmap.recycle()
        }
    }

    private fun detectFaces(source: Bitmap): List<RectF> {
        // Small detector input limits latency and memory on older phones.
        val scale = min(1f, FACE_DETECTOR_MAX_SIDE.toFloat() / max(source.width, source.height))
        val detectorBitmap = if (scale < 0.999f) {
            Bitmap.createScaledBitmap(
                source,
                max(1, (source.width * scale).toInt()),
                max(1, (source.height * scale).toInt()),
                true
            )
        } else source
        return try {
            val detected = Tasks.await(
                faceDetector.process(InputImage.fromBitmap(detectorBitmap, 0)),
                FACE_DETECTION_TIMEOUT_SECONDS,
                TimeUnit.SECONDS
            )
            val inverseScale = 1f / scale
            detected.mapNotNull { face ->
                val box = face.boundingBox
                RectF(
                    box.left * inverseScale,
                    box.top * inverseScale,
                    box.right * inverseScale,
                    box.bottom * inverseScale
                ).apply {
                    intersect(0f, 0f, source.width.toFloat(), source.height.toFloat())
                }.takeIf { it.width() > 2f && it.height() > 2f }
            }
        } catch (_: Exception) {
            emptyList()
        } finally {
            if (detectorBitmap !== source && !detectorBitmap.isRecycled) detectorBitmap.recycle()
        }
    }

    /**
     * Histogram-aware exposure, soft highlight roll-off, restrained split toning,
     * detail restoration and a subtle lens-style vignette. Processes one row at a time.
     */
    private fun finishPhoto(source: Bitmap, faces: List<RectF>, cinematic: Boolean): Bitmap {
        val width = source.width
        val height = source.height
        val exposure = estimateExposure(source)
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val row = IntArray(width)
        val above = IntArray(width)
        val below = IntArray(width)
        val out = IntArray(width)

        val cx = (width - 1) / 2f
        val cy = (height - 1) / 2f
        val invRx = 1f / max(1f, width * 0.72f)
        val invRy = 1f / max(1f, height * 0.72f)

        for (y in 0 until height) {
            val yPrev = (y - 1).coerceAtLeast(0)
            val yNext = (y + 1).coerceAtMost(height - 1)
            source.getPixels(row, 0, width, 0, y, width, 1)
            source.getPixels(above, 0, width, 0, yPrev, width, 1)
            source.getPixels(below, 0, width, 0, yNext, width, 1)

            for (x in 0 until width) {
                val color = row[x]
                val a = Color.alpha(color)
                val r = Color.red(color).toFloat()
                val g = Color.green(color).toFloat()
                val b = Color.blue(color).toFloat()
                val luma = 0.2126f * r + 0.7152f * g + 0.0722f * b

                // Gentle local detail; suppress the boost in very dark pixels to avoid amplifying noise.
                val lumaNeighbours = (
                    lumaOf(above[x]) + lumaOf(below[x]) +
                        lumaOf(row[(x - 1).coerceAtLeast(0)]) +
                        lumaOf(row[(x + 1).coerceAtMost(width - 1)])) * 0.25f
                val detail = ((luma - lumaNeighbours) * DETAIL_STRENGTH *
                    (luma / 42f).coerceIn(0f, 1f)).coerceIn(-7f, 7f)

                // Low-light chroma smoothing reduces coloured speckles without flattening luma detail.
                val noiseReduction = LOW_LIGHT_CHROMA_DENOISE *
                    ((exposure - 1f) / 0.28f).coerceIn(0f, 1f) *
                    (1f - luma / 190f).coerceIn(0f, 1f)
                val topPixel = above[x]
                val bottomPixel = below[x]
                val leftPixel = row[(x - 1).coerceAtLeast(0)]
                val rightPixel = row[(x + 1).coerceAtMost(width - 1)]
                val topLuma = lumaOf(topPixel)
                val bottomLuma = lumaOf(bottomPixel)
                val leftLuma = lumaOf(leftPixel)
                val rightLuma = lumaOf(rightPixel)
                val averageChromaR = (
                    (Color.red(topPixel) - topLuma) + (Color.red(bottomPixel) - bottomLuma) +
                        (Color.red(leftPixel) - leftLuma) + (Color.red(rightPixel) - rightLuma)
                    ) * 0.25f
                val averageChromaG = (
                    (Color.green(topPixel) - topLuma) + (Color.green(bottomPixel) - bottomLuma) +
                        (Color.green(leftPixel) - leftLuma) + (Color.green(rightPixel) - rightLuma)
                    ) * 0.25f
                val averageChromaB = (
                    (Color.blue(topPixel) - topLuma) + (Color.blue(bottomPixel) - bottomLuma) +
                        (Color.blue(leftPixel) - leftLuma) + (Color.blue(rightPixel) - rightLuma)
                    ) * 0.25f
                val smoothR = luma + ((r - luma) * (1f - noiseReduction) + averageChromaR * noiseReduction)
                val smoothG = luma + ((g - luma) * (1f - noiseReduction) + averageChromaG * noiseReduction)
                val smoothB = luma + ((b - luma) * (1f - noiseReduction) + averageChromaB * noiseReduction)

                val normalized = (luma / 255f).coerceIn(0f, 1f)
                val exposed = (normalized * exposure).coerceAtLeast(0f)
                var mapped = highlightShoulder(exposed)
                mapped = (0.5f + (mapped - 0.5f) * BASE_CONTRAST).coerceIn(0f, 1f)
                mapped = mapped.pow(SHADOW_GAMMA)
                val targetLuma = mapped * 255f + detail
                val safeLuma = max(1f, luma)
                val ratio = (targetLuma / safeLuma).coerceIn(0.35f, 2.1f)

                var nr = smoothR * ratio
                var ng = smoothG * ratio
                var nb = smoothB * ratio

                val nx = (x - cx) * invRx
                val ny = (y - cy) * invRy
                val radial = (nx * nx + ny * ny).coerceIn(0f, 1.4f)
                val vignette = (1f - VIGNETTE_STRENGTH * smoothstep(0.35f, 1.22f, radial)).coerceIn(0.90f, 1f)
                nr *= vignette
                ng *= vignette
                nb *= vignette

                val outputLum = (0.2126f * nr + 0.7152f * ng + 0.0722f * nb).coerceIn(0f, 255f)
                val shadow = (1f - outputLum / 150f).coerceIn(0f, 1f)
                val highlight = ((outputLum - 112f) / 143f).coerceIn(0f, 1f)
                val faceProtection = faceProtection(x.toFloat(), y.toFloat(), faces)
                val gradeAmount = if (cinematic) CINEMA_GRADE_STRENGTH * (1f - faceProtection * 0.82f) else 0f

                // Restrained teal in shadows and warm highlights. Face regions remain more neutral.
                nr += (highlight * 5.2f - shadow * 1.6f) * gradeAmount
                ng += (highlight * 1.3f) * gradeAmount
                nb += (shadow * 3.8f - highlight * 3.5f) * gradeAmount

                // Mild saturation control: protect bright skin and avoid neon-looking foliage.
                val saturation = (if (cinematic) 0.965f else 0.99f) + faceProtection * 0.025f
                val finalLum = 0.2126f * nr + 0.7152f * ng + 0.0722f * nb
                nr = finalLum + (nr - finalLum) * saturation
                ng = finalLum + (ng - finalLum) * saturation
                nb = finalLum + (nb - finalLum) * saturation

                out[x] = Color.argb(
                    a,
                    nr.toInt().coerceIn(0, 255),
                    ng.toInt().coerceIn(0, 255),
                    nb.toInt().coerceIn(0, 255)
                )
            }
            output.setPixels(out, 0, width, 0, y, width, 1)
        }
        return output
    }

    private fun estimateExposure(source: Bitmap): Float {
        val sampleScale = min(1f, HISTOGRAM_SAMPLE_SIDE.toFloat() / max(source.width, source.height))
        val sample = if (sampleScale < 0.999f) {
            Bitmap.createScaledBitmap(
                source,
                max(1, (source.width * sampleScale).toInt()),
                max(1, (source.height * sampleScale).toInt()),
                true
            )
        } else source
        return try {
            val histogram = IntArray(256)
            val pixels = IntArray(sample.width * sample.height)
            sample.getPixels(pixels, 0, sample.width, 0, 0, sample.width, sample.height)
            for (pixel in pixels) histogram[lumaOf(pixel).toInt().coerceIn(0, 255)]++
            val count = pixels.size
            val medianTarget = (count * 0.48f).toInt()
            var cumulative = 0
            var median = 112
            for (i in histogram.indices) {
                cumulative += histogram[i]
                if (cumulative >= medianTarget) { median = i; break }
            }
            // Avoid over-brightening deliberately dark/night scenes.
            (112f / max(48, median).toFloat()).coerceIn(0.82f, 1.28f)
        } finally {
            if (sample !== source && !sample.isRecycled) sample.recycle()
        }
    }

    private fun faceProtection(x: Float, y: Float, faces: List<RectF>): Float {
        var strongest = 0f
        for (face in faces) {
            val centerX = face.centerX()
            val centerY = face.centerY()
            val rx = max(1f, face.width() * 0.62f)
            val ry = max(1f, face.height() * 0.72f)
            val dx = (x - centerX) / rx
            val dy = (y - centerY) / ry
            val distance = sqrt((dx * dx + dy * dy).toDouble()).toFloat()
            val protection = 1f - smoothstep(0.62f, 1.08f, distance)
            strongest = max(strongest, protection)
        }
        return strongest.coerceIn(0f, 1f)
    }

    private fun highlightShoulder(value: Float): Float {
        val x = value.coerceIn(0f, 1.5f)
        if (x <= 0.72f) return x
        val denominator = 1f - exp(-(1.5f - 0.72f) / 0.28f)
        val shoulder = (1f - exp(-(x - 0.72f) / 0.28f)) / denominator
        return (0.72f + 0.28f * shoulder).coerceIn(0f, 1f)
    }

    private fun smoothstep(edge0: Float, edge1: Float, value: Float): Float {
        val t = ((value - edge0) / (edge1 - edge0)).coerceIn(0f, 1f)
        return t * t * (3f - 2f * t)
    }

    private fun lumaOf(color: Int): Float =
        0.2126f * Color.red(color) + 0.7152f * Color.green(color) + 0.0722f * Color.blue(color)

    private fun loadOriented(file: File): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.absolutePath, bounds)
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
            throw IllegalStateException("ملف الصورة غير صالح")
        }
        var sample = 1
        while ((bounds.outWidth.toLong() / (sample * 2L)) *
            (bounds.outHeight.toLong() / (sample * 2L)) > MAX_PROCESSING_PIXELS) {
            sample *= 2
        }
        val source = BitmapFactory.decodeFile(
            file.absolutePath,
            BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
        ) ?: throw IllegalStateException("تعذر فك ترميز الصورة")
        val orientation = ExifInterface(file.absolutePath).getAttributeInt(
            ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL
        )
        val matrix = Matrix()
        when (orientation) {
            ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
            ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
            ExifInterface.ORIENTATION_FLIP_VERTICAL -> matrix.setScale(1f, -1f)
            ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
            ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
            ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
            else -> return source
        }
        val transformed = Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        if (transformed !== source) source.recycle()
        return transformed
    }

    override fun close() {
        superRes.close()
        portrait.close()
        faceDetector.close()
    }

    companion object {
        private const val SR_MAX_INPUT_SIDE = 2000
        private const val MAX_PROCESSING_PIXELS = 12_000_000L
        private const val FACE_DETECTOR_MAX_SIDE = 1280
        private const val FACE_DETECTION_TIMEOUT_SECONDS = 5L
        private const val HISTOGRAM_SAMPLE_SIDE = 256
        private const val JPEG_QUALITY = 97
        private const val DETAIL_STRENGTH = 0.14f
        private const val LOW_LIGHT_CHROMA_DENOISE = 0.16f
        private const val BASE_CONTRAST = 1.045f
        private const val SHADOW_GAMMA = 0.965f
        private const val VIGNETTE_STRENGTH = 0.045f
        private const val CINEMA_GRADE_STRENGTH = 0.78f
    }
}
