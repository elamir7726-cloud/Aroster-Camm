package com.aroster.cam

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View

/** Minimal rule-of-thirds guide. It is visual only and does not modify captured frames. */
class GridOverlay @JvmOverloads constructor(
    context: Context, attrs: AttributeSet? = null
) : View(context, attrs) {
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99FFFFFF.toInt()
        strokeWidth = resources.displayMetrics.density
        style = Paint.Style.STROKE
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val thirdW = width / 3f
        val thirdH = height / 3f
        canvas.drawLine(thirdW, 0f, thirdW, height.toFloat(), linePaint)
        canvas.drawLine(thirdW * 2f, 0f, thirdW * 2f, height.toFloat(), linePaint)
        canvas.drawLine(0f, thirdH, width.toFloat(), thirdH, linePaint)
        canvas.drawLine(0f, thirdH * 2f, width.toFloat(), thirdH * 2f, linePaint)
    }
}
