package com.aroster.cam

import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

object ImageSaver {
    private const val ROOT_FOLDER = "AROSTER CAMM"

    /** Saves a JPEG in Pictures/AROSTER CAMM, optionally inside a named session folder. */
    fun saveJpeg(
        context: Context,
        jpeg: ByteArray,
        name: String,
        subFolder: String? = null
    ): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val relativePath = buildString {
                    append(Environment.DIRECTORY_PICTURES)
                    append("/")
                    append(ROOT_FOLDER)
                    if (!subFolder.isNullOrBlank()) {
                        append("/")
                        append(subFolder.replace("/", "_").trim())
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, relativePath)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val resolver = context.contentResolver
                val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: return false
                try {
                    resolver.openOutputStream(uri, "w")?.use { it.write(jpeg) }
                        ?: throw IllegalStateException("تعذر فتح ملف الصورة")
                    values.clear()
                    values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(uri, values, null, null)
                    true
                } catch (e: Exception) {
                    resolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val pictures = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES)
                val dir = File(pictures, buildString {
                    append(ROOT_FOLDER)
                    if (!subFolder.isNullOrBlank()) append("/").append(subFolder.replace("/", "_").trim())
                }).apply { if (!exists() && !mkdirs()) throw IllegalStateException("تعذر إنشاء مجلد الصور") }
                val file = File(dir, name)
                file.writeBytes(jpeg)
                MediaScannerConnection.scanFile(context, arrayOf(file.absolutePath), arrayOf("image/jpeg"), null)
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
