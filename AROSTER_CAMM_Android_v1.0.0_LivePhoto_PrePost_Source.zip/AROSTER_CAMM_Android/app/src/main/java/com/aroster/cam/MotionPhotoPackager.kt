package com.aroster.cam

import java.io.ByteArrayOutputStream
import java.nio.charset.StandardCharsets

/**
 * Builds a Google Camera-compatible Motion Photo JPEG:
 * JPEG + XMP APP1 metadata + MP4 payload appended after JPEG EOI.
 * MicroVideoOffset is the byte count from the end of the file to the MP4 start.
 */
object MotionPhotoPackager {
    private const val XMP_ID = "http://ns.adobe.com/xap/1.0/\u0000"
    private const val GOOGLE_CAMERA_NS = "http://ns.google.com/photos/1.0/camera/"

    fun embedMp4(jpeg: ByteArray, mp4: ByteArray, presentationTimestampUs: Long = 1_500_000L): ByteArray {
        require(jpeg.size > 4 && jpeg[0] == 0xFF.toByte() && jpeg[1] == 0xD8.toByte()) {
            "Input is not a valid JPEG"
        }
        require(mp4.size > 12 && mp4[4] == 'f'.code.toByte() && mp4[5] == 't'.code.toByte() &&
            mp4[6] == 'y'.code.toByte() && mp4[7] == 'p'.code.toByte()) {
            "Input is not a valid MP4"
        }

        val xmp = """
            <?xpacket begin="﻿" id="W5M0MpCehiHzreSzNTczkc9d"?>
            <x:xmpmeta xmlns:x="adobe:ns:meta/">
              <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
                <rdf:Description rdf:about=""
                  xmlns:GCamera="$GOOGLE_CAMERA_NS"
                  GCamera:MotionPhoto="1"
                  GCamera:MotionPhotoVersion="1"
                  GCamera:MicroVideo="1"
                  GCamera:MicroVideoVersion="1"
                  GCamera:MicroVideoOffset="${mp4.size}"
                  GCamera:MicroVideoPresentationTimestampUs="$presentationTimestampUs" />
              </rdf:RDF>
            </x:xmpmeta>
            <?xpacket end="w"?>
        """.trimIndent().toByteArray(StandardCharsets.UTF_8)
        val identifier = XMP_ID.toByteArray(StandardCharsets.US_ASCII)
        val payloadLength = identifier.size + xmp.size
        val segmentLength = payloadLength + 2
        require(segmentLength <= 0xFFFF) { "XMP metadata is too large" }

        val out = ByteArrayOutputStream(jpeg.size + mp4.size + payloadLength + 4)
        // JPEG SOI
        out.write(jpeg, 0, 2)
        // APP1 marker and big-endian segment length
        out.write(0xFF)
        out.write(0xE1)
        out.write((segmentLength shr 8) and 0xFF)
        out.write(segmentLength and 0xFF)
        out.write(identifier)
        out.write(xmp)
        // Original JPEG data after SOI, including EOI
        out.write(jpeg, 2, jpeg.size - 2)
        // Motion video payload follows JPEG EOI
        out.write(mp4)
        return out.toByteArray()
    }
}
