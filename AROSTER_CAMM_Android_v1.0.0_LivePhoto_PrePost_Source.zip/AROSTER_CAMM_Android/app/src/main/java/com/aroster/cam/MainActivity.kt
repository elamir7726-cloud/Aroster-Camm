package com.aroster.cam

import android.Manifest
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.util.Size
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import android.net.Uri
import android.provider.OpenableColumns
import com.aroster.cam.panorama.PanoramaStitcher
import com.aroster.cam.panorama.SpherePanoramaStitcher
import com.aroster.cam.ai.NightStackProcessor
import com.aroster.cam.ai.MotionPhotoBuffer
import com.aroster.cam.ai.MotionPhotoVideoEncoder
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageCapture
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.video.FallbackStrategy
import androidx.camera.video.MediaStoreOutputOptions
import androidx.camera.video.FileOutputOptions
import androidx.camera.video.Quality
import androidx.camera.video.QualitySelector
import androidx.camera.video.Recorder
import androidx.camera.video.Recording
import androidx.camera.video.VideoCapture
import androidx.camera.video.VideoRecordEvent
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.aroster.cam.ai.PhotoPipeline
import com.aroster.cam.ai.SmartShotAnalyzer
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.PI
import kotlin.math.asin
import kotlin.math.atan2
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.min

class MainActivity : ComponentActivity(), SensorEventListener {

    private enum class CaptureMode { PHOTO, VIDEO, PORTRAIT, PANORAMA, NIGHT, SPHERE }

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var flashButton: TextView
    private lateinit var aiButton: TextView
    private lateinit var portraitButton: TextView
    private lateinit var photoButton: TextView
    private lateinit var videoButton: TextView
    private lateinit var panoramaButton: TextView
    private lateinit var nightButton: TextView
    private lateinit var sphereButton: TextView
    private lateinit var cinemaButton: TextView
    private lateinit var motionButton: TextView
    private lateinit var videoLabButton: TextView
    private lateinit var shutterLabel: TextView
    private lateinit var zoomSeekBar: SeekBar
    private lateinit var exposureSeekBar: SeekBar
    private lateinit var zoomLabel: TextView
    private lateinit var exposureLabel: TextView
    private lateinit var timerButton: TextView
    private lateinit var gridButton: TextView
    private lateinit var focusHint: TextView
    private lateinit var gridOverlay: GridOverlay

    private val analysisExecutor = Executors.newSingleThreadExecutor()
    private val processExecutor = Executors.newSingleThreadExecutor()
    private val mainExecutor by lazy { ContextCompat.getMainExecutor(this) }
    private val mainHandler = Handler(Looper.getMainLooper())

    private var pipeline: PhotoPipeline? = null
    private lateinit var smartShot: SmartShotAnalyzer
    private var imageCapture: ImageCapture? = null
    private var videoCapture: VideoCapture<Recorder>? = null
    private var analysisAvailable = false
    private var camera: Camera? = null
    private var cameraRebinding = false
    private var activeRecording: Recording? = null
    private var lensFacing = CameraSelector.LENS_FACING_BACK
    private var lastGoodLens = CameraSelector.LENS_FACING_BACK

    private var mode = CaptureMode.PHOTO
    private var flashMode = FLASH_OFF
    private var portraitOn = false
    private var smartOn = false
    private var cinematicOn = true
    private var motionPhotoOn = false
    private val motionPhotoBuffer = MotionPhotoBuffer()
    private var pendingVideoStart = false
    @Volatile private var capturing = false

    private var sensorManager: SensorManager? = null
    private var rotationSensor: Sensor? = null
    private var previousAzimuth: Float? = null
    private var panoramaTurnDegrees = 0f
    private var panoramaCount = 0
    private var panoramaFolder = ""
    private var panoramaScratchDir: File? = null
    private data class SphereTarget(val yawOffsetDegrees: Float, val pitchOffsetDegrees: Float)
    private val sphereFrames = ArrayList<SpherePanoramaStitcher.Frame>()
    private var sphereTargets = emptyList<SphereTarget>()
    private var sphereScratchDir: File? = null
    private var sphereBaseYaw = 0f
    private var sphereBasePitch = 0f
    private var sphereTargetIndex = 0
    private var sphereStableSinceMs = 0L
    private var sphereLastCaptureMs = 0L
    private var sphereLastCandidateYaw: Float? = null
    private var sphereLastCandidatePitch: Float? = null
    private var sphereCapturePending = false
    private var currentRotationMatrix: FloatArray? = null

    private val nightFrameFiles = ArrayList<File>()
    private var nightOriginalExposureIndex = 0
    private var nightTargetExposureIndex = 0
    private var nightSessionName = ""
    private val gyroSamples = ArrayList<Pair<Long, Float>>()
    private var videoStartSensorNs = 0L
    private var currentVideoBase = ""
    private var videoEnhancing = false
    private var timerSeconds = 0
    private var gridEnabled = false
    private var exposureLower = 0
    private var exposureUpper = 0
    private var isUpdatingControlUi = false
    private var pendingTimerRunnable: Runnable? = null
    private lateinit var scaleGestureDetector: ScaleGestureDetector
    private var pinchGestureSeen = false

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { result ->
            if (cameraGranted()) startCamera() else showMessage("لازم تسمح للتطبيق باستخدام الكاميرا")
        }

    private val videoPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) enhanceSelectedVideo(uri)
    }

    private val audioPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (pendingVideoStart) {
                pendingVideoStart = false
                if (mode == CaptureMode.VIDEO) {
                    beginVideoRecording(withAudio = granted)
                    if (!granted) showMessage("هيتسجل الفيديو من غير صوت لأن إذن الميكروفون مرفوض")
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        flashButton = findViewById(R.id.flashButton)
        aiButton = findViewById(R.id.aiButton)
        portraitButton = findViewById(R.id.portraitMode)
        photoButton = findViewById(R.id.photoMode)
        videoButton = findViewById(R.id.videoMode)
        panoramaButton = findViewById(R.id.panoramaMode)
        nightButton = findViewById(R.id.nightMode)
        sphereButton = findViewById(R.id.sphereMode)
        cinemaButton = findViewById(R.id.cinemaButton)
        motionButton = findViewById(R.id.motionButton)
        videoLabButton = findViewById(R.id.videoLabButton)
        shutterLabel = findViewById(R.id.shutterLabel)
        zoomSeekBar = findViewById(R.id.zoomSeekBar)
        exposureSeekBar = findViewById(R.id.exposureSeekBar)
        zoomLabel = findViewById(R.id.zoomLabel)
        exposureLabel = findViewById(R.id.exposureLabel)
        timerButton = findViewById(R.id.timerButton)
        gridButton = findViewById(R.id.gridButton)
        focusHint = findViewById(R.id.focusHint)
        gridOverlay = findViewById(R.id.gridOverlay)

        configureProControls()
        scaleGestureDetector = ScaleGestureDetector(this,
            object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleBegin(detector: ScaleGestureDetector): Boolean {
                    pinchGestureSeen = true
                    return true
                }
                override fun onScale(detector: ScaleGestureDetector): Boolean {
                    val state = camera?.cameraInfo?.zoomState?.value ?: return false
                    val ratio = (state.zoomRatio * detector.scaleFactor)
                        .coerceIn(state.minZoomRatio, state.maxZoomRatio)
                    camera?.cameraControl?.setZoomRatio(ratio)
                    return true
                }
            })
        previewView.setOnTouchListener { _, event ->
            scaleGestureDetector.onTouchEvent(event)
            if (event.action == MotionEvent.ACTION_UP) {
                if (!pinchGestureSeen && !scaleGestureDetector.isInProgress) focusAt(event.x, event.y)
                pinchGestureSeen = false
            }
            true
        }

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        rotationSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        smartShot = SmartShotAnalyzer { takePhoto() }

        findViewById<View>(R.id.shutterButton).setOnClickListener { onShutterPressed() }
        findViewById<View>(R.id.switchButton).setOnClickListener { switchCamera() }
        findViewById<View>(R.id.galleryButton).setOnClickListener { openGallery() }
        flashButton.setOnClickListener { cycleFlash() }
        aiButton.setOnClickListener { toggleSmartShot() }
        portraitButton.setOnClickListener { selectMode(CaptureMode.PORTRAIT) }
        photoButton.setOnClickListener { selectMode(CaptureMode.PHOTO) }
        videoButton.setOnClickListener { selectMode(CaptureMode.VIDEO) }
        panoramaButton.setOnClickListener { selectMode(CaptureMode.PANORAMA) }
        nightButton.setOnClickListener { selectMode(CaptureMode.NIGHT) }
        sphereButton.setOnClickListener { selectMode(CaptureMode.SPHERE) }
        cinemaButton.setOnClickListener { toggleCinema() }
        motionButton.setOnClickListener { toggleMotionPhoto() }
        videoLabButton.setOnClickListener { pickVideoForEnhancement() }

        updateControls()
        val permissions = mutableListOf(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            permissions.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) startCamera() else permissionLauncher.launch(missing.toTypedArray())
    }

    private fun cameraGranted() = ContextCompat.checkSelfPermission(
        this, Manifest.permission.CAMERA
    ) == PackageManager.PERMISSION_GRANTED

    private fun startCamera() {
        cameraRebinding = true
        val future = ProcessCameraProvider.getInstance(this)
        future.addListener({
            val provider = try { future.get() } catch (e: Exception) {
                cameraRebinding = false
                showMessage("تعذر تهيئة خدمة الكاميرا")
                return@addListener
            }

            val selector = CameraSelector.Builder().requireLensFacing(lensFacing).build()
            val info = try { provider.getCameraInfo(selector) } catch (e: Exception) {
                if (lensFacing != lastGoodLens) {
                    lensFacing = lastGoodLens
                    showMessage("الكاميرا المطلوبة غير متاحة على الجهاز")
                    startCamera()
                } else {
                    cameraRebinding = false
                    showMessage("لم يتم العثور على كاميرا متاحة")
                }
                return@addListener
            }

            val stabilizationSupported = try {
                Recorder.getVideoCapabilities(info).isStabilizationSupported
            } catch (_: Exception) { false }

            val preview = Preview.Builder()
                .setPreviewStabilizationEnabled(stabilizationSupported)
                .build().also { it.setSurfaceProvider(previewView.surfaceProvider) }

            val capture = ImageCapture.Builder()
                .setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY)
                .setJpegQuality(98)
                .setFlashMode(if (flashMode == FLASH_PHOTO) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF)
                .build()

            val recorder = Recorder.Builder()
                .setQualitySelector(
                    QualitySelector.from(
                        Quality.FHD,
                        FallbackStrategy.lowerQualityOrHigherThan(Quality.SD)
                    )
                ).build()
            val video = VideoCapture.Builder(recorder)
                .setVideoStabilizationEnabled(stabilizationSupported)
                .build()

            val analysis = ImageAnalysis.Builder()
                .setTargetResolution(Size(640, 480))
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also { useCase ->
                    useCase.setAnalyzer(analysisExecutor) { proxy ->
                        if (motionPhotoOn && mode == CaptureMode.PHOTO) {
                            try { motionPhotoBuffer.offer(proxy) } catch (_: Exception) { }
                        }
                        if (smartOn) smartShot.analyze(proxy) else proxy.close()
                    }
                }

            try {
                provider.unbindAll()
                camera = provider.bindToLifecycle(this, selector, preview, capture, video, analysis)
                observeCameraControls(camera!!)
                videoCapture = video
                imageCapture = capture
                analysisAvailable = true
                cameraRebinding = false
                lastGoodLens = lensFacing
                capture.targetRotation = previewView.display?.rotation ?: android.view.Surface.ROTATION_0
                video.targetRotation = capture.targetRotation
                applyTorch()
                updateControls(stabilizationSupported)
            } catch (_: Exception) {
                // Some low-end camera HALs cannot bind four use cases at once.
                try {
                    provider.unbindAll()
                    camera = provider.bindToLifecycle(this, selector, preview, capture, video)
                    observeCameraControls(camera!!)
                    videoCapture = video
                    imageCapture = capture
                    analysisAvailable = false
                    cameraRebinding = false
                    lastGoodLens = lensFacing
                    capture.targetRotation = previewView.display?.rotation ?: android.view.Surface.ROTATION_0
                    video.targetRotation = capture.targetRotation
                    applyTorch()
                    updateControls(stabilizationSupported)
                    showMessage("تم تشغيل الكاميرا بوضع توافق الجهاز")
                } catch (_: Exception) {
                    try {
                        provider.unbindAll()
                        camera = provider.bindToLifecycle(this, selector, preview, capture)
                        observeCameraControls(camera!!)
                        imageCapture = capture
                        videoCapture = null
                        analysisAvailable = false
                        cameraRebinding = false
                        lastGoodLens = lensFacing
                        applyTorch()
                        updateControls(false)
                        showMessage("التصوير متاح، لكن الفيديو غير مدعوم على إعداد الكاميرا الحالي")
                    } catch (_: Exception) {
                        cameraRebinding = false
                        showMessage("تعذر تشغيل الكاميرا على هذا الجهاز")
                    }
                }
            }
        }, mainExecutor)
    }

    private fun onShutterPressed() {
        when (mode) {
            CaptureMode.VIDEO -> {
                if (activeRecording != null) stopRecording()
                else requestAndStartVideo()
            }
            CaptureMode.PANORAMA -> capturePanoramaFrame()
            CaptureMode.NIGHT -> startNightCapture()
            CaptureMode.SPHERE -> currentRotationMatrix?.let { captureSphereFrame(it.copyOf()) }
                ?: showMessage("مستشعر الاتجاه غير متاح على هذا الجهاز")
            else -> schedulePhotoCapture()
        }
    }

    private fun configureProControls() {
        zoomSeekBar.max = 1000
        zoomLabel.setOnLongClickListener {
            val minimum = camera?.cameraInfo?.zoomState?.value?.minZoomRatio
            if (minimum != null) camera?.cameraControl?.setZoomRatio(minimum)
            true
        }
        exposureLabel.setOnLongClickListener {
            val range = exposureLower..exposureUpper
            if (0 in range) camera?.cameraControl?.setExposureCompensationIndex(0)
            true
        }
        zoomSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || isUpdatingControlUi) return
                val state = camera?.cameraInfo?.zoomState?.value ?: return
                val ratio = state.minZoomRatio +
                    (state.maxZoomRatio - state.minZoomRatio) * (progress / 1000f)
                camera?.cameraControl?.setZoomRatio(ratio)
                zoomLabel.text = String.format(Locale.US, "%.1f×", ratio)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) = Unit
            override fun onStopTrackingTouch(bar: SeekBar?) = Unit
        })

        exposureSeekBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(bar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser || isUpdatingControlUi) return
                val index = (exposureLower + progress).coerceIn(exposureLower, exposureUpper)
                camera?.cameraControl?.setExposureCompensationIndex(index)
                val step = camera?.cameraInfo?.exposureState?.exposureCompensationStep
                val ev = if (step != null) index * step.toFloat() else 0f
                exposureLabel.text = String.format(Locale.US, "EV %+.1f", ev)
            }
            override fun onStartTrackingTouch(bar: SeekBar?) = Unit
            override fun onStopTrackingTouch(bar: SeekBar?) = Unit
        })

        timerButton.setOnClickListener {
            timerSeconds = when (timerSeconds) { 0 -> 3; 3 -> 5; 5 -> 10; else -> 0 }
            timerButton.text = if (timerSeconds == 0) "TIMER OFF" else "${timerSeconds}s TIMER"
            timerButton.setTextColor(if (timerSeconds == 0) WHITE else GOLD)
        }
        gridButton.setOnClickListener {
            gridEnabled = !gridEnabled
            gridOverlay.visibility = if (gridEnabled) View.VISIBLE else View.GONE
            gridButton.setTextColor(if (gridEnabled) GOLD else WHITE)
            showMessage(if (gridEnabled) "خطوط التكوين مفعّلة" else "خطوط التكوين متوقفة")
        }
    }

    private fun observeCameraControls(boundCamera: Camera) {
        boundCamera.cameraInfo.zoomState.observe(this) { state ->
            if (state == null) return@observe
            isUpdatingControlUi = true
            try {
                val span = (state.maxZoomRatio - state.minZoomRatio).coerceAtLeast(0.001f)
                zoomSeekBar.progress = (((state.zoomRatio - state.minZoomRatio) / span) * 1000f)
                    .toInt().coerceIn(0, 1000)
                zoomLabel.text = String.format(Locale.US, "%.1f×", state.zoomRatio)
            } finally { isUpdatingControlUi = false }
        }

        val exposure = boundCamera.cameraInfo.exposureState
        exposureLower = exposure.exposureCompensationRange.lower
        exposureUpper = exposure.exposureCompensationRange.upper
        isUpdatingControlUi = true
        try {
            val range = (exposureUpper - exposureLower).coerceAtLeast(0)
            exposureSeekBar.max = range
            exposureSeekBar.progress = (exposure.exposureCompensationIndex - exposureLower).coerceIn(0, range)
            val ev = exposure.exposureCompensationIndex * exposure.exposureCompensationStep.toFloat()
            exposureLabel.text = String.format(Locale.US, "EV %+.1f", ev)
            exposureSeekBar.isEnabled = range > 0
        } finally { isUpdatingControlUi = false }
    }

    private fun focusAt(x: Float, y: Float) {
        val activeCamera = camera ?: return
        val point = previewView.meteringPointFactory.createPoint(x, y)
        val action = FocusMeteringAction.Builder(point)
            .setAutoCancelDuration(3, TimeUnit.SECONDS)
            .build()
        focusHint.text = "FOCUSING…"
        val focusFuture = activeCamera.cameraControl.startFocusAndMetering(action)
        focusFuture.addListener({
            val result = runCatching { focusFuture.get() }.getOrNull()
            focusHint.text = if (result?.isFocusSuccessful == true) "FOCUS LOCKED" else "TAP TO FOCUS"
        }, mainExecutor)
    }

    private fun schedulePhotoCapture() {
        if (timerSeconds <= 0) {
            if (motionPhotoOn && mode == CaptureMode.PHOTO) captureMotionPhoto() else takePhoto()
            return
        }
        if (pendingTimerRunnable != null) return
        val originalMode = mode
        var remaining = timerSeconds
        val task = object : Runnable {
            override fun run() {
                if (mode != originalMode || isFinishing) {
                    pendingTimerRunnable = null
                    statusText.text = "PHOTO TIMER CANCELLED"
                    return
                }
                if (remaining <= 0) {
                    pendingTimerRunnable = null
                    if (motionPhotoOn && mode == CaptureMode.PHOTO) captureMotionPhoto() else takePhoto()
                    updateControls()
                    return
                }
                statusText.text = "CAPTURE IN  $remaining"
                remaining--
                mainHandler.postDelayed(this, 1000L)
            }
        }
        pendingTimerRunnable = task
        mainHandler.post(task)
    }

    private fun takePhoto(fileName: String? = null, subFolder: String? = null, sphereRotation: FloatArray? = null) {
        val capture = imageCapture ?: return showMessage("الكاميرا لسه بتجهز")
        if (capturing) return
        capturing = true
        val source = File(cacheDir, "capture_${System.nanoTime()}.jpg")
        val portrait = portraitOn && mode == CaptureMode.PORTRAIT
        val cinema = cinematicOn
        val name = fileName ?: "AROSTER_${timestamp()}.jpg"
        val output = ImageCapture.OutputFileOptions.Builder(source).build()

        capture.takePicture(output, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputResults: ImageCapture.OutputFileResults) {
                processExecutor.execute {
                    var saved = false
                    val result = try {
                        val jpeg = if (sphereRotation != null) {
                            source.readBytes()
                        } else {
                            val photoPipeline = pipeline ?: PhotoPipeline(applicationContext).also { pipeline = it }
                            photoPipeline.process(source, portrait, cinema)
                        }
                        val isPanoramaFrame = mode == CaptureMode.PANORAMA && subFolder == panoramaFolder && name.startsWith("PANO_")
                        if (isPanoramaFrame) {
                            val scratch = panoramaScratchDir ?: File(cacheDir, "panorama/$panoramaFolder").also {
                                it.mkdirs(); panoramaScratchDir = it
                            }
                            File(scratch, name).writeBytes(jpeg)
                        }
                        if (sphereRotation != null) {
                            val scratch = sphereScratchDir ?: File(cacheDir, "photo_sphere").also {
                                it.mkdirs(); sphereScratchDir = it
                            }
                            val sphereFile = File(scratch, name)
                            sphereFile.writeBytes(jpeg)
                            sphereFrames.add(SpherePanoramaStitcher.Frame(sphereFile, sphereRotation.copyOf()))
                            saved = true
                        } else {
                            saved = ImageSaver.saveJpeg(applicationContext, jpeg, name, subFolder)
                        }
                        source.delete()
                        if (sphereRotation != null) "تم التقاط جزء من صورة 360°" else if (saved) "اتحفظت الصورة في Pictures/AROSTER CAMM" else "تعذر حفظ الصورة"
                    } catch (e: Exception) {
                        source.delete()
                        "فشلت معالجة الصورة: ${e.message ?: "خطأ غير معروف"}"
                    }
                    runOnUiThread {
                        capturing = false
                        if (saved && sphereRotation != null) {
                            sphereCapturePending = false
                            sphereTargetIndex = (sphereTargetIndex + 1).coerceAtMost(sphereTargets.size)
                            sphereStableSinceMs = 0L
                            sphereLastCaptureMs = SystemClock.elapsedRealtime()
                        }
                        if (saved && subFolder == panoramaFolder && name.startsWith("PANO_")) {
                            panoramaCount = (panoramaCount + 1).coerceAtMost(PANORAMA_FRAMES)
                        }
                        if (sphereRotation == null && mode != CaptureMode.PANORAMA) showMessage(result)
                        updateControls()
                        if (saved && sphereRotation != null && sphereTargetIndex >= sphereTargets.size) finishSphereSet()
                        if (saved && mode == CaptureMode.PANORAMA && panoramaCount >= PANORAMA_FRAMES) finishPanoramaSet()
                    }
                }
            }

            override fun onError(exception: ImageCaptureException) {
                capturing = false
                sphereCapturePending = false
                source.delete()
                sphereStableSinceMs = 0L
                showMessage("فشل التصوير: ${exception.message ?: "خطأ غير معروف"}")
            }
        })
    }

    private fun requestAndStartVideo() {
        if (videoCapture == null) return showMessage("تسجيل الفيديو غير متاح على هذا الجهاز")
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            beginVideoRecording(withAudio = true)
        } else {
            pendingVideoStart = true
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun beginVideoRecording(withAudio: Boolean) {
        val capture = videoCapture ?: return showMessage("تسجيل الفيديو غير متاح")
        if (activeRecording != null) return
        val name = "AROSTER_VIDEO_${timestamp()}.mp4"
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/AROSTER CAMM")
            }
        }
        val output = MediaStoreOutputOptions.Builder(
            contentResolver, MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        ).setContentValues(values).build()

        try {
            gyroSamples.clear()
            videoStartSensorNs = 0L
            currentVideoBase = name.removeSuffix(".mp4")
            var pending = capture.output.prepareRecording(this, output)
            if (withAudio && ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                pending = pending.withAudioEnabled()
            }
            activeRecording = pending.start(mainExecutor) { event ->
                when (event) {
                    is VideoRecordEvent.Start -> {
                        // Align the motion log to the actual recording start, not the button tap.
                        gyroSamples.clear()
                        videoStartSensorNs = SystemClock.elapsedRealtimeNanos()
                        shutterLabel.text = "STOP"
                        statusText.text = "● REC  •  ${if (stabilizationLabel) "STABILIZED" else "STANDARD"}"
                    }
                    is VideoRecordEvent.Finalize -> {
                        activeRecording = null
                        if (!event.hasError()) saveGyroLog(currentVideoBase)
                        updateControls()
                        if (event.hasError()) showMessage("تعذر إنهاء تسجيل الفيديو")
                        else showMessage("اتحفظ الفيديو مع بيانات الجيروسكوب؛ افتح VIDEO LAB لتحسينه")
                    }
                }
            }
        } catch (_: Exception) {
            activeRecording = null
            showMessage("فشل بدء تسجيل الفيديو")
        }
    }

    private fun stopRecording() {
        activeRecording?.stop()
        shutterLabel.text = "●"
    }

    /** Captures a 3-second Motion Photo: 1.5s pre-roll + shutter + 1.5s post-roll. */
    private fun captureMotionPhoto() {
        val capture = imageCapture ?: return showMessage("الكاميرا لسه بتجهز")
        if (activeRecording != null || capturing || cameraRebinding) return
        val shutterTime = System.currentTimeMillis()
        if (!motionPhotoBuffer.hasPreRoll(shutterTime)) {
            return showMessage("استنى ثانية ونص بعد تفعيل Live Photo عشان نسجل اللحظة اللي قبل التصوير")
        }

        capturing = true
        val base = "AROSTER_${timestamp()}_LIVE"
        val stillFile = File(cacheDir, "${base}_still.jpg")
        val motionFile = File(cacheDir, "${base}_motion.mp4")
        val stillOutput = ImageCapture.OutputFileOptions.Builder(stillFile).build()
        val preFrames = motionPhotoBuffer.snapshot(shutterTime - 1_500L, shutterTime)

        capture.takePicture(stillOutput, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputResults: ImageCapture.OutputFileResults) {
                mainHandler.postDelayed({
                    val postFrames = motionPhotoBuffer.snapshot(shutterTime, shutterTime + 1_650L)
                    processExecutor.execute {
                        var saved = false
                        var message = "تعذر إنشاء Live Photo"
                        try {
                            val combined = (preFrames + postFrames)
                                .distinctBy { it.timestampMs }
                                .sortedBy { it.timestampMs }
                                .filter { it.timestampMs in (shutterTime - 1_500L)..(shutterTime + 1_500L) }
                            if (combined.size < 24 || combined.last().timestampMs - combined.first().timestampMs < 2_700L) {
                                throw IllegalStateException("لم تكتمل الثواني الثلاث من الحركة")
                            }
                            MotionPhotoVideoEncoder.encode(combined, motionFile)
                            val photoPipeline = pipeline ?: PhotoPipeline(applicationContext).also { pipeline = it }
                            val processedJpeg = photoPipeline.process(stillFile, false, cinematicOn)
                            val motionJpeg = MotionPhotoPackager.embedMp4(processedJpeg, motionFile.readBytes(), 1_500_000L)
                            saved = ImageSaver.saveJpeg(applicationContext, motionJpeg, "$base.jpg", "Live Photos")
                            message = if (saved) "تم حفظ Live Photo: ثانية ونصف قبل التصوير وثانية ونصف بعده" else "تعذر حفظ Live Photo"
                        } catch (e: Exception) {
                            message = "فشل تجهيز Live Photo: ${e.message ?: "خطأ غير معروف"}"
                        } finally {
                            stillFile.delete()
                            motionFile.delete()
                        }
                        runOnUiThread {
                            capturing = false
                            showMessage(message)
                            updateControls()
                        }
                    }
                }, LIVE_PHOTO_POST_ROLL_MS)
            }

            override fun onError(exception: ImageCaptureException) {
                stillFile.delete()
                capturing = false
                showMessage("فشل التقاط صورة Live Photo: ${exception.message ?: "خطأ كاميرا"}")
                updateControls()
            }
        })
        motionButton.text = "LIVE 3S • REC"
        showMessage("Live Photo: تسجيل 1.5 ثانية قبل وبعد لحظة التصوير")
    }

    private fun startNightCapture() {
        if (cameraRebinding) return showMessage("الكاميرا بتتجهز، جرّب التصوير بعد ظهور المعاينة")
        val capture = imageCapture ?: return showMessage("الكاميرا لسه بتجهز")
        if (capturing) return
        if (lensFacing != CameraSelector.LENS_FACING_BACK) return showMessage("وضع Night Sight متاح بالكاميرا الخلفية فقط")

        capturing = true
        nightFrameFiles.clear()
        nightSessionName = "AROSTER_NIGHT_${timestamp()}.jpg"
        val state = camera?.cameraInfo?.exposureState
        nightOriginalExposureIndex = state?.exposureCompensationIndex ?: 0
        val range = state?.exposureCompensationRange
        val step = state?.exposureCompensationStep?.toFloat() ?: 0f
        val extraSteps = if (step > 0.001f) (1.2f / step).roundToInt() else 0
        nightTargetExposureIndex = if (range != null) {
            (nightOriginalExposureIndex + extraSteps).coerceIn(range.lower, range.upper)
        } else nightOriginalExposureIndex

        // Night mode avoids flash/torch because every frame in the stack must share the same lighting.
        flashMode = FLASH_OFF
        capture.flashMode = ImageCapture.FLASH_MODE_OFF
        applyTorch()
        flashButton.text = "⚡"
        flashButton.setTextColor(WHITE)
        statusText.text = "NIGHT SIGHT  •  PREPARING SENSOR"
        showMessage("Night Sight: اثبت الموبايل لحظة، جاري التقاط 4 إطارات")

        val activeCamera = camera
        val future = if (activeCamera != null && nightTargetExposureIndex != nightOriginalExposureIndex) {
            runCatching { activeCamera.cameraControl.setExposureCompensationIndex(nightTargetExposureIndex) }.getOrNull()
        } else null
        if (future == null) {
            mainHandler.postDelayed({ captureNightFrame(0) }, 300L)
        } else {
            future.addListener({
                runCatching { future.get() }
                mainHandler.postDelayed({ captureNightFrame(0) }, 320L)
            }, mainExecutor)
        }
    }

    private fun captureNightFrame(index: Int) {
        val capture = imageCapture
        if (capture == null || cameraRebinding || mode != CaptureMode.NIGHT) {
            finishNightCapture("تم إلغاء وضع Night")
            return
        }
        if (index >= NIGHT_FRAME_COUNT) {
            finishNightCapture(null)
            return
        }
        statusText.text = "NIGHT SIGHT  •  FRAME ${index + 1}/$NIGHT_FRAME_COUNT"
        val source = File(cacheDir, "night_${System.nanoTime()}_$index.jpg")
        val output = ImageCapture.OutputFileOptions.Builder(source).build()
        capture.takePicture(output, mainExecutor, object : ImageCapture.OnImageSavedCallback {
            override fun onImageSaved(outputResults: ImageCapture.OutputFileResults) {
                nightFrameFiles.add(source)
                if (index + 1 < NIGHT_FRAME_COUNT) {
                    mainHandler.postDelayed({ captureNightFrame(index + 1) }, 170L)
                } else {
                    finishNightCapture(null)
                }
            }

            override fun onError(exception: ImageCaptureException) {
                source.delete()
                if (nightFrameFiles.size >= 3) finishNightCapture(null)
                else finishNightCapture("تعذر التقاط إطارات Night Sight")
            }
        })
    }

    private fun finishNightCapture(errorMessage: String?) {
        camera?.cameraControl?.setExposureCompensationIndex(nightOriginalExposureIndex)
        val files = nightFrameFiles.toList()
        nightFrameFiles.clear()
        if (errorMessage != null || files.size < 3) {
            files.forEach { it.delete() }
            capturing = false
            updateControls()
            showMessage(errorMessage ?: "لقطات Night غير كافية")
            return
        }

        statusText.text = "NIGHT SIGHT  •  ALIGNING FRAMES"
        processExecutor.execute {
            val merged = File(cacheDir, "night_merged_${System.nanoTime()}.jpg")
            var saved = false
            val failure = runCatching {
                NightStackProcessor.merge(files, merged, 2200)
                val photoPipeline = pipeline ?: PhotoPipeline(applicationContext).also { pipeline = it }
                val jpeg = photoPipeline.process(merged, false, cinematicOn)
                saved = ImageSaver.saveJpeg(applicationContext, jpeg, nightSessionName, null)
            }.exceptionOrNull()
            files.forEach { it.delete() }
            merged.delete()
            runOnUiThread {
                capturing = false
                updateControls()
                showMessage(
                    if (saved) "تم حفظ صورة Night Sight بعد دمج ${files.size} إطارات"
                    else "فشل دمج صور Night: ${failure?.message ?: "تعذر الحفظ"}"
                )
            }
        }
    }

    private fun buildSphereTargets(): List<SphereTarget> {
        val result = ArrayList<SphereTarget>(48)
        val yawSteps = (0..11).map { it * 30f }
        for (pitch in listOf(0f, 35f, -35f)) {
            yawSteps.forEach { yaw -> result += SphereTarget(yaw, pitch) }
        }
        for (pitch in listOf(78f, -78f)) {
            listOf(0f, 60f, 120f, 180f, 240f, 300f).forEach { yaw -> result += SphereTarget(yaw, pitch) }
        }
        return result
    }

    private fun captureSphereFrame(rotation: FloatArray) {
        if (capturing || cameraRebinding || sphereCapturePending || mode != CaptureMode.SPHERE) return
        if (imageCapture == null) return showMessage("الكاميرا لسه بتجهز")
        if (sphereTargetIndex >= sphereTargets.size) return finishSphereSet()
        sphereCapturePending = true
        val fileName = "SPHERE_${(sphereTargetIndex + 1).toString().padStart(2, '0')}.jpg"
        statusText.text = "PHOTO SPHERE  •  CAPTURING ${sphereTargetIndex + 1}/${sphereTargets.size}"
        takePhoto(fileName, null, rotation)
    }

    private fun finishSphereSet() {
        val frames = sphereFrames.toList()
        val input = sphereScratchDir
        mode = CaptureMode.PHOTO
        sphereCapturePending = false
        sphereTargetIndex = 0
        sphereTargets = emptyList()
        currentRotationMatrix = null
        updateControls()
        if (frames.size < 18 || input == null) {
            input?.deleteRecursively()
            sphereFrames.clear()
            sphereScratchDir = null
            showMessage("صورة 360° غير مكتملة. التقط عددًا أكبر من الاتجاهات")
            return
        }
        capturing = true
        statusText.text = "PHOTO SPHERE  •  STITCHING ${frames.size} FRAMES"
        showMessage("جاري بناء صورة Photo Sphere كروية وحفظ بيانات GPano...")
        processExecutor.execute {
            val output = File(cacheDir, "AROSTER_PHOTO_SPHERE_${timestamp()}.jpg")
            val result = runCatching { SpherePanoramaStitcher.stitch(frames, output, 2048) }
            val saved = result.getOrNull()?.let {
                // Keep the GPano XMP block injected by the sphere stitcher intact.
                ImageSaver.saveJpeg(applicationContext, it.file.readBytes(), it.file.name, null)
            } ?: false
            output.delete()
            input.deleteRecursively()
            runOnUiThread {
                capturing = false
                sphereFrames.clear()
                sphereScratchDir = null
                updateControls()
                showMessage(
                    if (saved) "تم إنشاء صورة 360° كروية وحفظها في Pictures/AROSTER CAMM"
                    else "تعذر دمج Photo Sphere: ${result.exceptionOrNull()?.message ?: "حاول بإضاءة أفضل وحركة أبطأ"}"
                )
            }
        }
    }

    private fun capturePanoramaFrame() {
        if (panoramaCount >= PANORAMA_FRAMES) {
            finishPanoramaSet()
            return
        }
        val next = panoramaCount + 1
        val name = "PANO_${next.toString().padStart(2, '0')}.jpg"
        takePhoto(name, panoramaFolder)
    }

    private fun finishPanoramaSet() {
        val input = panoramaScratchDir
        mode = CaptureMode.PHOTO
        resetPanoramaTracking()
        updateControls()
        if (input == null || !input.isDirectory) {
            showMessage("صور البانوراما غير مكتملة")
            return
        }
        showMessage("جاري دمج صور الجولة في بانوراما أفقية...")
        processExecutor.execute {
            val output = File(cacheDir, "AROSTER_PANORAMA_${timestamp()}.jpg")
            val result = runCatching { PanoramaStitcher.stitch(input, output, 1024) }
            val saved = result.getOrNull()?.let {
                ImageSaver.saveJpeg(applicationContext, it.file.readBytes(), it.file.name, null)
            } ?: false
            output.delete()
            input.deleteRecursively()
            runOnUiThread {
                panoramaScratchDir = null
                showMessage(if (saved) "تم إنشاء البانوراما الأفقية وحفظها في Pictures/AROSTER CAMM" else
                    "تعذر دمج الصور. جرّب الإضاءة الجيدة والتدوير ببطء مع تداخل اللقطات")
            }
        }
    }

    private fun selectMode(newMode: CaptureMode) {
        if (newMode != mode) {
            pendingTimerRunnable?.let { mainHandler.removeCallbacks(it) }
            pendingTimerRunnable = null
        }
        if (capturing && newMode != mode) {
            showMessage("استنى حفظ الصورة الحالية قبل تغيير وضع التصوير")
            return
        }
        if (activeRecording != null && newMode != CaptureMode.VIDEO) stopRecording()
        if (mode == CaptureMode.SPHERE && newMode != CaptureMode.SPHERE) {
            sphereScratchDir?.deleteRecursively()
            sphereScratchDir = null
            sphereFrames.clear()
            sphereTargets = emptyList()
            sphereTargetIndex = 0
            sphereCapturePending = false
        }
        mode = newMode
        portraitOn = newMode == CaptureMode.PORTRAIT
        if (newMode == CaptureMode.PANORAMA) {
            panoramaCount = 0
            panoramaFolder = "Panorama_${timestamp()}"
            panoramaScratchDir = File(cacheDir, "panorama/$panoramaFolder").also { it.mkdirs() }
            resetPanoramaTracking()
        }
        if (newMode == CaptureMode.NIGHT || newMode == CaptureMode.SPHERE) {
            if (lensFacing != CameraSelector.LENS_FACING_BACK) {
                lensFacing = CameraSelector.LENS_FACING_BACK
                startCamera()
            }
        }
        if (newMode == CaptureMode.NIGHT) {
            flashMode = FLASH_OFF
            imageCapture?.flashMode = ImageCapture.FLASH_MODE_OFF
            applyTorch()
        }
        if (newMode == CaptureMode.SPHERE) {
            val rotation = currentRotationMatrix
            if (rotationSensor == null || rotation == null) {
                mode = CaptureMode.PHOTO
                showMessage("وضع Photo Sphere يحتاج مستشعر اتجاه في الهاتف")
                updateControls()
                return
            }
            sphereFrames.clear()
            sphereTargetIndex = 0
            sphereTargets = buildSphereTargets()
            sphereScratchDir = File(cacheDir, "photo_sphere_${timestamp()}").also { it.mkdirs() }
            val directionX = -rotation[2]
            val directionY = -rotation[5]
            val directionZ = -rotation[8]
            sphereBaseYaw = atan2(directionX, -directionZ)
            sphereBasePitch = asin(directionY.coerceIn(-1f, 1f))
            sphereStableSinceMs = 0L
            sphereLastCaptureMs = 0L
            sphereLastCandidateYaw = null
            sphereLastCandidatePitch = null
            sphereCapturePending = false
            showMessage("Photo Sphere: وجّه الكاميرا حسب إرشاد H/V وثبّتها. 48 لقطة تلقائية")
        }
        updateControls()
    }

    private fun switchCamera() {
        if (mode == CaptureMode.NIGHT || mode == CaptureMode.SPHERE) {
            return showMessage("وضع Night وPhoto Sphere يستخدمان الكاميرا الخلفية فقط")
        }
        pendingTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingTimerRunnable = null
        if (capturing) return showMessage("استنى حفظ الصورة الحالية قبل تبديل الكاميرا")
        if (activeRecording != null) return showMessage("أوقف الفيديو قبل تبديل الكاميرا")
        lensFacing = if (lensFacing == CameraSelector.LENS_FACING_BACK)
            CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
        startCamera()
    }

    private fun cycleFlash() {
        if (mode == CaptureMode.NIGHT || mode == CaptureMode.SPHERE) {
            showMessage("الفلاش متوقف في أوضاع Night وPhoto Sphere")
            return
        }
        flashMode = (flashMode + 1) % 3
        imageCapture?.flashMode = if (flashMode == FLASH_PHOTO) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        applyTorch()
        flashButton.text = when (flashMode) {
            FLASH_PHOTO -> "⚡ ON"
            FLASH_TORCH -> "🔦"
            else -> "⚡"
        }
        flashButton.setTextColor(if (flashMode == FLASH_OFF) WHITE else GOLD)
    }

    private fun applyTorch() {
        camera?.cameraControl?.enableTorch(
            flashMode == FLASH_TORCH && lensFacing == CameraSelector.LENS_FACING_BACK
        )
    }

    private fun toggleSmartShot() {
        if (!analysisAvailable) {
            showMessage("AI Smart Shot غير متاح مع وضع توافق الكاميرا الحالي")
            return
        }
        smartOn = !smartOn
        smartShot.enabled = smartOn
        aiButton.alpha = if (smartOn) 1f else 0.65f
        updateControls()
        showMessage(if (smartOn) "AI Smart Shot شغال" else "AI Smart Shot متوقف")
    }

    private fun toggleCinema() {
        cinematicOn = !cinematicOn
        updateControls()
        showMessage(if (cinematicOn) "تدرج سينمائي للصور مفعّل" else "التدرج السينمائي متوقف")
    }

    private fun toggleMotionPhoto() {
        motionPhotoOn = !motionPhotoOn
        motionButton.text = if (motionPhotoOn) "LIVE PHOTO 3S ✓" else "LIVE PHOTO"
        updateControls()
        showMessage(if (motionPhotoOn) "Live Photo مفعّل: صورة مع فيديو مدمج مدته 3 ثوانٍ" else "Live Photo متوقف")
    }

    private var stabilizationLabel = false

    private fun updateControls(stabilizationAvailable: Boolean? = null) {
        if (stabilizationAvailable != null) stabilizationLabel = stabilizationAvailable
        photoButton.isSelected = mode == CaptureMode.PHOTO
        videoButton.isSelected = mode == CaptureMode.VIDEO
        portraitButton.isSelected = mode == CaptureMode.PORTRAIT
        panoramaButton.isSelected = mode == CaptureMode.PANORAMA
        nightButton.isSelected = mode == CaptureMode.NIGHT
        sphereButton.isSelected = mode == CaptureMode.SPHERE
        photoButton.setTextColor(if (photoButton.isSelected) GOLD else WHITE)
        videoButton.setTextColor(if (videoButton.isSelected) GOLD else WHITE)
        portraitButton.setTextColor(if (portraitButton.isSelected) GOLD else WHITE)
        panoramaButton.setTextColor(if (panoramaButton.isSelected) GOLD else WHITE)
        nightButton.setTextColor(if (nightButton.isSelected) GOLD else WHITE)
        sphereButton.setTextColor(if (sphereButton.isSelected) GOLD else WHITE)
        cinemaButton.alpha = if (cinematicOn) 1f else 0.58f
        motionButton.alpha = if (motionPhotoOn) 1f else 0.58f
        motionButton.text = if (motionPhotoOn) "LIVE PHOTO 3S ✓" else "LIVE PHOTO"
        cinemaButton.visibility = if (mode == CaptureMode.VIDEO) View.GONE else View.VISIBLE
        motionButton.visibility = if (mode == CaptureMode.PHOTO) View.VISIBLE else View.GONE
        videoLabButton.visibility = if (mode == CaptureMode.VIDEO) View.VISIBLE else View.GONE
        timerButton.visibility = if (mode == CaptureMode.PHOTO || mode == CaptureMode.PORTRAIT) View.VISIBLE else View.GONE
        gridButton.visibility = if (mode == CaptureMode.SPHERE) View.GONE else View.VISIBLE
        exposureSeekBar.alpha = if (mode == CaptureMode.NIGHT || mode == CaptureMode.SPHERE) 0.55f else 1f
        exposureSeekBar.isEnabled = (exposureUpper - exposureLower) > 0 &&
            mode != CaptureMode.NIGHT && mode != CaptureMode.SPHERE
        val currentExposure = camera?.cameraInfo?.exposureState?.let {
            it.exposureCompensationIndex * it.exposureCompensationStep.toFloat()
        } ?: 0f
        exposureLabel.text = when (mode) {
            CaptureMode.NIGHT -> "NIGHT +1.2"
            CaptureMode.SPHERE -> "360° SPHERE"
            else -> String.format(Locale.US, "EV %+.1f", currentExposure)
        }
        shutterLabel.text = when {
            mode == CaptureMode.VIDEO && activeRecording != null -> "STOP"
            mode == CaptureMode.VIDEO -> "REC"
            mode == CaptureMode.PANORAMA -> "ADD"
            mode == CaptureMode.NIGHT -> "NIGHT"
            mode == CaptureMode.SPHERE -> "AUTO"
            motionPhotoOn -> "LIVE 3S"
            else -> "●"
        }
        statusText.text = when (mode) {
            CaptureMode.VIDEO -> if (stabilizationLabel) "VIDEO  •  ELECTRONIC STABILIZATION READY" else "VIDEO  •  DEVICE STABILIZATION UNAVAILABLE"
            CaptureMode.PANORAMA -> "PANO GUIDE  •  ${panoramaCount}/$PANORAMA_FRAMES  •  ${panoramaTurnDegrees.toInt()}° TURN"
            CaptureMode.NIGHT -> "NIGHT SIGHT  •  4-FRAME LOW-LIGHT STACK"
            CaptureMode.SPHERE -> "PHOTO SPHERE  •  AIM ${min(sphereTargetIndex + 1, sphereTargets.size)}/${sphereTargets.size}  •  360°"
            CaptureMode.PORTRAIT -> "PORTRAIT  •  ON-DEVICE SEGMENTATION"
            CaptureMode.PHOTO -> "PHOTO  •  ${if (cinematicOn) "CINEMATIC" else "NATURAL"}  •  READY"
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, "image/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try { startActivity(intent) } catch (_: Exception) { showMessage("مفيش تطبيق معرض متاح") }
    }

    private fun pickVideoForEnhancement() {
        if (videoEnhancing) return showMessage("فيه فيديو بيتعالج بالفعل")
        videoPicker.launch(arrayOf("video/mp4", "video/*"))
    }

    private fun enhanceSelectedVideo(uri: Uri) {
        if (videoEnhancing) return
        videoEnhancing = true
        val displayName = queryDisplayName(uri) ?: "AROSTER_VIDEO_${timestamp()}.mp4"
        val base = displayName.substringBeforeLast('.')
        val gyroFile = File(File(filesDir, "gyro"), "$base.csv")
        showMessage(
            if (gyroFile.isFile) "جاري تطبيق التدرج السينمائي وتصحيح دوران الجيروسكوب..."
            else "جاري تطبيق التدرج السينمائي وقصّ بسيط للحواف..."
        )
        val output = File(cacheDir, "${base}_CINEMATIC.mp4")
        VideoEnhancer(this).export(uri, output, gyroFile.takeIf { it.isFile },
            onComplete = { file ->
                processExecutor.execute {
                    val saved = saveEnhancedVideo(file)
                    file.delete()
                    runOnUiThread {
                        videoEnhancing = false
                        showMessage(if (saved) "تم حفظ النسخة السينمائية المحسّنة في Movies/AROSTER CAMM" else "اكتمل التصدير لكن تعذر حفظ النسخة")
                    }
                }
            },
            onError = { error ->
                output.delete()
                videoEnhancing = false
                showMessage("فشل تحسين الفيديو: ${error.message ?: "صيغة غير مدعومة"}")
            }
        )
    }

    private fun queryDisplayName(uri: Uri): String? {
        return runCatching {
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
        }.getOrNull()
    }

    private fun saveGyroLog(base: String) {
        if (gyroSamples.size < 5) return
        runCatching {
            val dir = File(filesDir, "gyro").apply { mkdirs() }
            File(dir, "$base.csv").bufferedWriter().use { writer ->
                gyroSamples.forEach { (timeUs, roll) -> writer.append(timeUs.toString()).append(',').append(roll.toString()).append('\n') }
            }
        }
        gyroSamples.clear()
    }

    private fun saveEnhancedVideo(file: File): Boolean {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, file.name)
                    put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                    put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/AROSTER CAMM/Enhanced")
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                try {
                    contentResolver.openOutputStream(uri, "w")?.use { out -> file.inputStream().use { it.copyTo(out) } }
                        ?: throw IllegalStateException("تعذر فتح ملف الفيديو")
                    val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
                    contentResolver.update(uri, done, null, null)
                    true
                } catch (e: Exception) {
                    contentResolver.delete(uri, null, null)
                    throw e
                }
            } else {
                val dir = File(android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_MOVIES), "AROSTER CAMM/Enhanced")
                    .apply { if (!exists() && !mkdirs()) throw IllegalStateException("تعذر إنشاء المجلد") }
                val target = File(dir, file.name)
                file.copyTo(target, overwrite = true)
                android.media.MediaScannerConnection.scanFile(this, arrayOf(target.absolutePath), arrayOf("video/mp4"), null)
                true
            }
        } catch (_: Exception) { false }
    }

    private fun timestamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    private fun showMessage(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun resetPanoramaTracking() {
        previousAzimuth = null
        panoramaTurnDegrees = 0f
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_ROTATION_VECTOR) return
        val matrix = FloatArray(9)
        val orientation = FloatArray(3)
        SensorManager.getRotationMatrixFromVector(matrix, event.values)
        currentRotationMatrix = matrix.copyOf()
        SensorManager.getOrientation(matrix, orientation)

        // Save low-rate roll samples while recording, so VIDEO LAB can correct gentle hand rotation.
        if (activeRecording != null && mode == CaptureMode.VIDEO && videoStartSensorNs > 0L) {
            val timeUs = ((event.timestamp - videoStartSensorNs) / 1_000L).coerceAtLeast(0L)
            if (gyroSamples.isEmpty() || timeUs - gyroSamples.last().first >= 20_000L) {
                var roll = orientation[2]
                val previousRoll = gyroSamples.lastOrNull()?.second
                if (previousRoll != null) {
                    val twoPi = (2.0 * PI).toFloat()
                    while (roll - previousRoll > PI.toFloat()) roll -= twoPi
                    while (roll - previousRoll < -PI.toFloat()) roll += twoPi
                }
                if (gyroSamples.size < 30_000) gyroSamples.add(timeUs to roll)
            }
        }

        if (mode == CaptureMode.SPHERE) {
            updateSphereAlignment(matrix)
            return
        }
        if (mode != CaptureMode.PANORAMA) return
        val azimuth = orientation[0]
        val previous = previousAzimuth
        if (previous != null) {
            var delta = azimuth - previous
            val pi = PI.toFloat()
            while (delta > pi) delta -= 2f * pi
            while (delta < -pi) delta += 2f * pi
            panoramaTurnDegrees = (panoramaTurnDegrees + abs(Math.toDegrees(delta.toDouble()).toFloat()))
                .coerceAtMost(360f)
            updateControls()
        }
        previousAzimuth = azimuth
    }

    private fun updateSphereAlignment(rotation: FloatArray) {
        if (cameraRebinding || sphereCapturePending || capturing || sphereTargetIndex >= sphereTargets.size) return
        val target = sphereTargets[sphereTargetIndex]
        val directionX = -rotation[2]
        val directionY = -rotation[5]
        val directionZ = -rotation[8]
        val yaw = atan2(directionX, -directionZ)
        val pitch = asin(directionY.coerceIn(-1f, 1f))
        val targetYaw = sphereBaseYaw + Math.toRadians(target.yawOffsetDegrees.toDouble()).toFloat()
        val targetPitch = (sphereBasePitch + Math.toRadians(target.pitchOffsetDegrees.toDouble()).toFloat())
            .coerceIn(-1.48f, 1.48f)
        var yawError = yaw - targetYaw
        while (yawError > PI.toFloat()) yawError -= 2f * PI.toFloat()
        while (yawError < -PI.toFloat()) yawError += 2f * PI.toFloat()
        val pitchError = pitch - targetPitch
        val errorDegrees = Math.toDegrees(sqrt(yawError * yawError + pitchError * pitchError).toDouble()).toFloat()
        val now = SystemClock.elapsedRealtime()
        val lastYaw = sphereLastCandidateYaw
        val lastPitch = sphereLastCandidatePitch
        val movement = if (lastYaw != null && lastPitch != null) {
            var yawDelta = yaw - lastYaw
            while (yawDelta > PI.toFloat()) yawDelta -= 2f * PI.toFloat()
            while (yawDelta < -PI.toFloat()) yawDelta += 2f * PI.toFloat()
            Math.toDegrees(sqrt(yawDelta * yawDelta + (pitch - lastPitch) * (pitch - lastPitch)).toDouble()).toFloat()
        } else Float.MAX_VALUE
        sphereLastCandidateYaw = yaw
        sphereLastCandidatePitch = pitch
        if (errorDegrees <= 5.0f && movement <= 1.25f) {
            if (sphereStableSinceMs == 0L) sphereStableSinceMs = now
            if (now - sphereStableSinceMs >= 500L && now - sphereLastCaptureMs >= 900L) {
                captureSphereFrame(rotation.copyOf())
            }
        } else {
            sphereStableSinceMs = 0L
        }
        statusText.text = if (errorDegrees <= 5.0f) {
            "PHOTO SPHERE  •  HOLD STILL  •  ${sphereTargetIndex + 1}/${sphereTargets.size}"
        } else {
            "PHOTO SPHERE  •  H ${Math.toDegrees(yawError.toDouble()).toInt()}°  V ${Math.toDegrees(pitchError.toDouble()).toInt()}°"
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onResume() {
        super.onResume()
        rotationSensor?.let { sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onPause() {
        pendingTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingTimerRunnable = null
        sensorManager?.unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        pendingTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        pendingTimerRunnable = null
        activeRecording?.stop()
        smartShot.close()
        processExecutor.execute { pipeline?.close() }
        processExecutor.shutdown()
        analysisExecutor.shutdown()
        super.onDestroy()
    }

    companion object {
        private const val LIVE_PHOTO_POST_ROLL_MS = 1_500L

        private const val FLASH_OFF = 0
        private const val FLASH_PHOTO = 1
        private const val FLASH_TORCH = 2
        private const val PANORAMA_FRAMES = 12
        private const val NIGHT_FRAME_COUNT = 4
        private val GOLD = Color.parseColor("#E8C66A")
        private val WHITE = Color.WHITE
    }
}
