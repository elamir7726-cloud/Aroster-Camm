package com.aroster.cam.ai

import android.content.Context
import android.graphics.Bitmap
import org.tensorflow.lite.Interpreter

/**
 * SKELETON لـ Frame Interpolation (RIFE).
 * بيولّد فريم في المنتصف بين فريمين.
 * TODO: الـ signature (الحجم، الترتيب، الـ normalization) لازم يتطابق مع
 * موديل RIFE اللي هتحوله لـ TFLite. الكود ده افتراضي وممكن يحتاج تعديل.
 * كمان الـ pipeline الكامل للفيديو (decode -> interpolate -> encode) لسه مش متنفذ.
 */
class FrameInterpolator(context: Context) : AutoCloseable {
    private val interpreter: Interpreter? =
        ModelLoader.mapAsset(context, MODEL)?.let {
            Interpreter(it, Interpreter.Options().setNumThreads(4))
        }

    val isAvailable: Boolean get() = interpreter != null

    fun interpolate(a: Bitmap, b: Bitmap): Bitmap? {
        val ip = interpreter ?: return null

        val sa = Bitmap.createScaledBitmap(a, SIZE, SIZE, true)
        val sb = Bitmap.createScaledBitmap(b, SIZE, SIZE, true)
        val pa = IntArray(SIZE * SIZE)
        val pb = IntArray(SIZE * SIZE)
        sa.getPixels(pa, 0, SIZE, 0, 0, SIZE, SIZE)
        sb.getPixels(pb, 0, SIZE, 0, 0, SIZE, SIZE)

        val input = Array(1) { Array(SIZE) { Array(SIZE) { FloatArray(6) } } }
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val i = y * SIZE + x
                val px = input[0][y][x]
                val ca = pa[i]
                val cb = pb[i]
                px[0] = ((ca shr 16) and 0xFF) / 255f
                px[1] = ((ca shr 8) and 0xFF) / 255f
                px[2] = (ca and 0xFF) / 255f
                px[3] = ((cb shr 16) and 0xFF) / 255f
                px[4] = ((cb shr 8) and 0xFF) / 255f
                px[5] = (cb and 0xFF) / 255f
            }
        }

        val output = Array(1) { Array(SIZE) { Array(SIZE) { FloatArray(3) } } }
        ip.run(input, output)

        val out = IntArray(SIZE * SIZE)
        for (y in 0 until SIZE) {
            for (x in 0 until SIZE) {
                val p = output[0][y][x]
                out[y * SIZE + x] = (0xFF shl 24) or
                    (toByte(p[0]) shl 16) or (toByte(p[1]) shl 8) or toByte(p[2])
            }
        }
        val mid = Bitmap.createBitmap(out, SIZE, SIZE, Bitmap.Config.ARGB_8888)
        return Bitmap.createScaledBitmap(mid, a.width, a.height, true)
    }

    private fun toByte(v: Float): Int = (v.coerceIn(0f, 1f) * 255f + 0.5f).toInt()

    override fun close() {
        interpreter?.close()
    }

    companion object {
        const val MODEL = "rife.tflite"
        private const val SIZE = 256
    }
}
